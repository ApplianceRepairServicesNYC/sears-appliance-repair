<?php $head_title="Contact || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Contact";
require_once('parts/page-title.php');
?>



        <!--Start Contact Page -->
        <section class="contact-page">
            <div class="container">
                <div class="contact-page__top">
                    <div class="row">
                        <!--Start Contact Page Top Map-->
                        <div class="col-xl-7">
                            <div class="contact-page__top-map">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619%3A0xba03efb7998eef6d!2sCostco+Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd"
                                    class="contact-page-google-map__one" allowfullscreen></iframe>
                            </div>
                        </div>
                        <!--End Contact Page Top Map-->

                        <!--Start Contact Page Top Content-->
                        <div class="col-xl-5">
                            <div class="contact-page__top-content">
                                <div class="title-box">
                                    <h2>Get In Touch With Us</h2>
                                    <p>Usemec for us to malase rogers inntestuing tocases
                                        interpases</p>
                                </div>

                                <div class="contact-page__top-content-single">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <span class="icon-location"></span>
                                        </div>

                                        <div class="content-box">
                                            <h2>Address</h2>
                                            <p>16 vastu arcade, 5rd Floor <br>
                                                palace road, London.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="contact-page__top-content-single">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <span class="icon-telephone-call
                                            "></span>
                                        </div>

                                        <div class="content-box">
                                            <h2>Phone</h2>
                                            <p class="number1"><a href="tel:123456789">88 256 256 2584 00</a></p>
                                            <p class="number2"><a href="tel:123456789">88 256 256 2584 00</a></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="contact-page__top-content-single mb0">
                                    <div class="inner">
                                        <div class="icon-box style2">
                                            <span class="icon-email"></span>
                                        </div>

                                        <div class="content-box">
                                            <h2>Email </h2>
                                            <p class="email1"><a href="mailto:info@gmail.com">info@gmail.com</a></p>
                                            <p class="email2"><a href="mailto:info@gmail.com">info@gmail.com</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Contact Page Top Content-->
                    </div>
                </div>

                <div class="contact-page__bottom">
                    <div class="row">
                        <!--Start Contact Page Bottom Content-->
                        <div class="col-xl-5">
                            <div class="contact-page__bottom-content">
                                <div class="sec-title style2">
                                    <div class="sec-title__tagline">
                                        <h6>Contact Us</h6>
                                    </div>
                                    <h2 class="sec-title__title">We’re always ready <br>
                                        to help you</h2>
                                </div>
                                <div class="text-box">
                                    <p>Dolor amety consectetur notted tempor inci labore
                                        dolore magna alique mauris auctor donec atestes
                                        ligulea kucacuse.</p>
                                </div>
                            </div>
                        </div>
                        <!--End Contact Page Bottom Content-->

                        <!--Start Contact One Form-->
                        <div class="col-xl-7">
                            <div class="contact-one__form contact-one__form--contact">
                                <form id="contact-form" name="contact_form" class="default-form2"
                                    action="https://unicktheme.com/lsicool/assets/inc/sendmail.php" method="post">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="text" name="form_name" value="" placeholder="Your Name"
                                                    required="">
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="email" name="form_email" value=""
                                                    placeholder="Email Address" required="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="text" placeholder="Phone" name="phone">
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="input-box">
                                                <input type="text" placeholder="Subject" name="subject">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="input-box">
                                                <textarea name="message" placeholder="Your Message"></textarea>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-6">
                                            <div class="contact-one__form-btn">
                                                <button class="thm-btn" type="submit"
                                                    data-loading-text="Please wait...">
                                                    <span class="txt">Send a Message</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--End Contact One Form-->
                    </div>
                </div>
            </div>
        </section>
        <!--Start Contact Page -->

        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>