<?php $head_title="404 || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "404";
require_once('parts/page-title.php');
?>

        <!--Start Error Page-->
        <section class="error-page">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="error-page__inner text-center">
                            <h2>404</h2>
                            <h3>Sorry, Something Went Wrong.</h3>
                            <p>The page you are looking for was moved, removed, renamed <br>
                                or never existed.</p>

                            <div class="error-page__search">
                                <form class="search-form" action="#">
                                    <input placeholder="Search ..." type="text">
                                    <button type="submit"><i class="icon-search-interface-symbol"></i></button>
                                </form>
                            </div>

                            <div class="error-page__btn">
                                <a class="thm-btn" href="index.php">
                                    <span class="txt">Back To Home</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Error Page-->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>

       