<?php $head_title="About || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "About";
require_once('parts/page-title.php');
?>


        <!--Start About One -->
        <section class="about-one">
            <div class="container">
                <div class="row">
                    <!--Start About One Img-->
                    <div class="col-xl-6">
                        <div class="about-one__img wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1500ms">
                            <div class="about-one__img-inner">
                                <img src="assets/images/about/about-v1-img1.jpg" alt="#">
                                <div class="experience-box">
                                    <h2>Experience Of <br> <span class="odometer" data-count="12">00</span> <span
                                            class="plus">+</span> Years
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About One Img-->

                    <!--Start About One Content-->
                    <div class="col-xl-6">
                        <div class="about-one__content">
                            <div class="big-title">
                                <h2>About Us</h2>
                            </div>
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>About Company</h6>
                                </div>
                                <h2 class="sec-title__title">Solutions For an Every <br> Repair Problems</h2>
                            </div>

                            <div class="about-one__content-text1">
                                <div class="text-box">
                                    <p>Niorem lsum dolor amety consectetur notted
                                        tempors incididunt labore dolore utn magna alique
                                        mauris id auctor donec atestes ligula lacus.</p>
                                </div>

                                <div class="icon-box">
                                    <span class="icon-air-conditioner"></span>
                                </div>
                            </div>

                            <div class="about-one__content-text2">
                                <div class="contant-box">
                                    <div class="contant-box-single">
                                        <div class="number-box">
                                            01
                                        </div>
                                        <div class="title-box">
                                            <h2>Safe Solutions <br> For Home</h2>
                                        </div>
                                    </div>

                                    <div class="contant-box-single mb0">
                                        <div class="number-box">
                                            02
                                        </div>
                                        <div class="title-box">
                                            <h2>Expert Team <br> Members</h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="img-box">
                                    <img src="assets/images/about/about-v1-img2.jpg" alt="#">
                                </div>
                            </div>

                            <div class="about-one__content-text3">
                                <div class="signature">
                                    <h3>Rabson Singhania</h3>
                                </div>
                                <div class="text-box">
                                    <h2>Ceo, Founder Of <br> Delta Group</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About One Content-->

                </div>
            </div>
        </section>
        <!--End About One -->

        <!--Start Features One -->
        <section class="features-one features-one--about">
            <div class="auto-container">
                <div class="features-one__inner">
                    <div class="container">
                        <div class="row">
                            <!--Start Features One Single-->
                            <div class="col-xl-6 col-lg-6 wow fadeInLeft" data-wow-delay="100ms"
                                data-wow-duration="1000ms">
                                <div class="features-one__single">
                                    <div class="features-one__single-img">
                                        <div class="inner">
                                            <img src="assets/images/resources/features-v1-img1.jpg" alt="#">
                                            <div class="icon-box">
                                                <span class="icon-maintenance-2"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="features-one__single-content">
                                        <h3>Servicing</h3>
                                        <h2><a href="cooling-services.php">Quality Checkup</a></h2>
                                        <p>Dolore utn magna alique mauris id auctor <br>
                                            donec atestes ligula kacus resons.</p>
                                    </div>
                                </div>
                            </div>
                            <!--End Features One Single-->

                            <!--Start Features One Single-->
                            <div class="col-xl-6 col-lg-6 wow fadeInRight" data-wow-delay="200ms"
                                data-wow-duration="1000ms">
                                <div class="features-one__single style2">
                                    <div class="features-one__single-img">
                                        <div class="inner">
                                            <img src="assets/images/resources/features-v1-img1.jpg" alt="#">
                                            <div class="icon-box">
                                                <span class="icon-maintenance"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="features-one__single-content">
                                        <h3>Servicing</h3>
                                        <h2><a href="cooling-services.php">Dust Cleaning</a></h2>
                                        <p>Dolore utn magna alique mauris id auctor <br>
                                            donec atestes ligula kacus resons.</p>
                                    </div>
                                </div>
                            </div>
                            <!--End Features One Single-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Features One -->

        <!--Start Video Two -->
        <section class="video-two video-two--about">
            <div class="video-two__bg" style="background-image: url(assets/images/backgrounds/video-v2-bg2.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="video-two__inner">
                            <div class="video-two__content">
                                <h2>Need An Air Contioner <br>
                                    Technician</h2>
                                <p>Kula kacuse every reson credit to develop level works.</p>
                                <div class="border-box"></div>
                                <div class="contact-box">
                                    <div class="icon-box">
                                        <span class="icon-telephone"></span>
                                    </div>

                                    <div class="content-box">
                                        <p>Call anytime</p>
                                        <a href="tel:000-987458741">+000-987458741</a>
                                    </div>
                                </div>
                            </div>

                            <div class="video-two__video">
                                <div class="shape3 float-bob-x"><img src="assets/images/shapes/video-v2-shape4.png"
                                        alt=""></div>
                                <div class="video-two__video-icon">
                                    <div class="shape1"><img src="assets/images/shapes/video-v2-shape1.png" alt="#">
                                    </div>
                                    <div class="shape2"><img src="assets/images/shapes/video-v2-shape1.png" alt="#">
                                    </div>
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="video-two__video-btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>

                                <div class="title-box">
                                    <h2>Watch How We Work</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Video Two -->

        <!--Start Features Five -->
        <section class="features-five features-five--about">
            <div class="auto-container">
                <div class="features-five__outer">
                    <div class="container">
                        <div class="features-five__inner clearfix">
                            <ul class="features-five__box clearfix">
                                <!--Start Features Five Single-->
                                <li class="wow animated fadeInUp" data-wow-delay="0.1s">
                                    <div class="img-box">
                                        <div class="inner">
                                            <div class="shape1"></div>
                                            <img src="assets/images/resources/features-v5-img1.png" alt="#">
                                        </div>
                                    </div>
                                </li>
                                <!--End Features Five Single-->

                                <!--Start Features Five Single-->
                                <li class="wow animated fadeInUp" data-wow-delay="0.2s">
                                    <div class="img-box">
                                        <div class="inner">
                                            <div class="shape1"></div>
                                            <img src="assets/images/resources/features-v5-img2.png" alt="#">
                                        </div>
                                    </div>
                                </li>
                                <!--End Features Five Single-->

                                <!--Start Features Five Single-->
                                <li class="wow animated fadeInUp" data-wow-delay="0.3s">
                                    <div class="img-box">
                                        <div class="inner">
                                            <div class="shape1"></div>
                                            <img src="assets/images/resources/features-v5-img3.png" alt="#">
                                        </div>
                                    </div>
                                </li>
                                <!--End Features Five Single-->

                                <!--Start Features Five Single-->
                                <li class="wow animated fadeInUp" data-wow-delay="0.4s">
                                    <div class="img-box">
                                        <div class="inner">
                                            <div class="shape1"></div>
                                            <img src="assets/images/resources/features-v5-img4.png" alt="#">
                                        </div>
                                    </div>
                                </li>
                                <!--End Features Five Single-->

                                <!--Start Features Five Single-->
                                <li class="wow animated fadeInUp" data-wow-delay="0.5s">
                                    <div class="img-box">
                                        <div class="inner">
                                            <div class="shape1"></div>
                                            <img src="assets/images/resources/features-v5-img5.png" alt="#">
                                        </div>
                                    </div>
                                </li>
                                <!--End Features Five Single-->

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Features Five -->

        <!--Start Work Two -->
        <section class="work-two work-two--about">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Working Process</h6>
                    </div>
                    <h2 class="sec-title__title">Solve your issues in 4 <br>
                        easy steps</h2>
                </div>
                <div class="row">
                    <!--Start Work Two Content-->
                    <div class="col-xl-7">
                        <div class="work-two__content">
                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single wow fadeInLeft" data-wow-delay="100ms"
                                data-wow-duration="1000ms">
                                <div class="content-box">
                                    <h2>Make an Appointment</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>

                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>1 <span>st</span></h2>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->

                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single style2 wow fadeInLeft" data-wow-delay="300ms"
                                data-wow-duration="1000ms">
                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>2 <span>nd</span></h2>
                                </div>
                                <div class="content-box">
                                    <h2>Select your services</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->

                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single mb0 wow fadeInLeft" data-wow-delay="400ms"
                                data-wow-duration="1000ms">
                                <div class="content-box">
                                    <h2>Confirm for services</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>

                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>3 <span>rd</span></h2>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->
                        </div>
                    </div>
                    <!--End Work Two Content-->

                    <!--Start Work Two Img-->
                    <div class="col-xl-5">
                        <div class="work-two__img clearfix">
                            <div class="inner clearfix">
                                <img src="assets/images/resources/work-v2-img1.png" alt="#">
                                <div class="work-two__video">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="work-two__video-btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Work Two Img-->
                </div>
            </div>
        </section>
        <!--End Work Two -->

        <!--Start Counter One -->
        <section class="counter-one counter-one--about">
            <div class="container">
                <div class="counter-one__inner">
                    <ul class="clearfix">
                        <li>
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>Fun Facts</h6>
                                </div>
                                <h2 class="sec-title__title">Counter</h2>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-maintenance-1"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="17">00</span> <span class="k">k</span>
                                    </h2>
                                    <p>Completed Project</p>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-man"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="49">00</span> <span class="k">+</span>
                                    </h2>
                                    <p>Satisfied Clients</p>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-target"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="2">00</span> <span class="k">k</span>
                                    </h2>
                                    <p>Awards Winner</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Counter One -->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>

       