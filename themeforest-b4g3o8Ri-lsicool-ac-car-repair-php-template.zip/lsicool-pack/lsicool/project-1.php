<?php $head_title="Project One || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Project One";
require_once('parts/page-title.php');
?>


        <!--Start Gallery One -->
        <section class="gallery-one gallery-one--project1">
            <div class="container">
                <div class="sec-title text-center">
                    <div class="sec-title__tagline">
                        <h6>recent gallery</h6>
                    </div>
                    <h2 class="sec-title__title">Our Recently Completed <br>
                        Projects List </h2>
                </div>
                <div class="row">

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img1.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img1.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img2.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img2.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img3.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img3.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img4.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img4.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img5.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img5.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->

                    <!--Start Gallery OneSingle-->
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="gallery-one__single">
                            <div class="gallery-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/project/project-page-v1-img6.jpg" alt="#">
                                </div>
                                <div class="overlay-content">
                                    <div class="text-box">
                                        <p>Checking Quality</p>
                                        <h2><a href="project-details.php">Repair Conditioner</a></h2>
                                    </div>

                                    <div class="gallery-one__link">
                                        <a class="img-popup2"
                                            href="assets/images/project/project-page-v1-img6.jpg"><span
                                                class="icon-plus"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Gallery One Single-->
                </div>
            </div>
        </section>
        <!--End Gallery One -->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>
       