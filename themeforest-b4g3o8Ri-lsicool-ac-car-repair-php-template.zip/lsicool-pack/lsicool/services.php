<?php $head_title="Services || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Services";
require_once('parts/page-title.php');
?>


        <!--Start Services Three -->
        <section class="services-three services-three--services">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Our Services</h6>
                    </div>
                    <h2 class="sec-title__title">Make your Ac feel like a <br>
                        brand new one</h2>
                </div>
                <div class="row">
                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img1.jpg" alt="#">
                                    <div class="number-box">
                                        01
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-maintenance-1"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 01</p>
                                        <h2><a href="cooling-services.php">Industrial Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->

                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img2.jpg" alt="#">
                                    <div class="number-box">
                                        02
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-maintenance"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 02</p>
                                        <h2><a href="cooling-services.php">Heating Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->

                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="200ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img3.jpg" alt="#">
                                    <div class="number-box">
                                        03
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-air-conditioner-1"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 03</p>
                                        <h2><a href="cooling-services.php">Cleaning Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->
                </div>
            </div>
        </section>
        <!--End Services Three -->

        <!--Start Why Choose One -->
        <section class="why-choose-one why-choose-one--services">
            <div class="why-choose-one__bg"
                style="background-image: url(assets/images/backgrounds/why-choose-v1-bg.jpg);"></div>
            <div class="container">
                <div class="why-choose-one__top">
                    <div class="sec-title">
                        <div class="sec-title__tagline">
                            <h6>Why Choose Us</h6>
                        </div>
                        <h2 class="sec-title__title">We Provide Full Range <br>
                            AC Services. </h2>
                    </div>

                    <div class="why-choose-one__top-text">
                        <p>Niorem lsum dolor amet consectetur notted temp incididunt
                            labore dolore utn magna alique mauris id auctor donec atestes
                            kacus for every resons of credits to develop in level.</p>
                    </div>
                </div>

                <div class="row">
                    <!--Start Why Choose One Img-->
                    <div class="col-xl-5">
                        <div class="why-choose-one__img">
                            <div class="inner">
                                <div class="shape1 float-bob-y"><img src="assets/images/shapes/why-choose-v1-shape1.png"
                                        alt="#">
                                </div>
                                <img src="assets/images/resources/why-choose-v1-img1.jpg" alt="#">
                                <div class="content-box">
                                    <div class="why-choose-one__icon">
                                        <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                            class="why-choose-one__btn video-popup">
                                            <span class="icon-play-1"></span>
                                        </a>
                                    </div>
                                    <h2>Watch Our <br>
                                        Video</h2>
                                </div>
                            </div>

                            <div class="why-choose-one__progress">
                                <div class="why-choose-one__progress-single">
                                    <div class="title-box">
                                        <h2>Industrial Electricians</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="87%">
                                            <div class="count-text">87%</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="why-choose-one__progress-single mb0">
                                    <div class="title-box">
                                        <h2>Residential Carpenters</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="60%">
                                            <div class="count-text">60%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Why Choose One Img-->

                    <!--Start Why Choose One Content-->
                    <div class="col-xl-7">
                        <div class="why-choose-one__content">
                            <div class="why-choose-one__content-bg"
                                style="background-image: url(assets/images/shapes/why-choose-bg.png);"></div>
                            <ul class="why-choose-one__content-list">
                                <li class="wow animated fadeInUp" data-wow-delay="0.1s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-maintenance-1"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>24/7 Customer Support</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="wow animated fadeInUp" data-wow-delay="0.2s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-air-conditioner-2"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>Affordable Service Prices</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="wow animated fadeInUp" data-wow-delay="0.3s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-air-conditioner-1"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>Safe Solution For Home</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Why Choose One Content-->
                </div>
            </div>
        </section>
        <!--End Why Choose One -->

        <!--Start Brand One-->
        <section class="brand-one">
            <div class="container">
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 5, "autoplay": { "delay": 5000 }, "breakpoints": {
                                    "0": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 1
                                    },
                                    "375": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 1
                                    },
                                    "575": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 2
                                    },
                                    "767": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 2
                                    },
                                    "991": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 3
                                    },
                                    "1199": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 4
                                    }
                                }}'>
                    <div class="swiper-wrapper">


                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img1.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img2.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img3.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img4.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img5.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img1.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img2.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v1-img3.png" alt="#">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Brand One -->

        <!--Start Products One -->
        <section class="product-one">
            <div class="shape1 float-bob-y"><img src="assets/images/shapes/product-v1-shape1.png" alt="#"></div>
            <div class="shape2 float-bob-y"><img src="assets/images/shapes/product-v1-shape1.png" alt="#"></div>
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Popular Products</h6>
                    </div>
                    <h2 class="sec-title__title">Browse our products</h2>
                </div>
                <div class="row">
                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.1s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Industry <br>
                                            air ventilation</a></h2>
                                    <p>$77.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img1.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.2s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Mutimedia <br>
                                            alarm devices</a></h2>
                                    <p>$89.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img2.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.3s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Industry <br>
                                            air ventilation</a></h2>
                                    <p>$21.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img3.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.4s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Air conditioner <br>
                                            heat pump</a></h2>
                                    <p>$64.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                            <li>
                                                <span class="icon-star1"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img4.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->
                </div>
            </div>
        </section>
        <!--End Products One -->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>