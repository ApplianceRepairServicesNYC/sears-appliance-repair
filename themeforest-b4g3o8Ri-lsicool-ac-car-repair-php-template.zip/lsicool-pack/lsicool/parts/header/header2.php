<!--Start Main Header Two-->
<header class="main-header main-header-two">
            <!--Start Main Header Two Top-->
            <div class="main-header-two__top">
                <div class="container">
                    <div class="main-header-two__top-inner">
                        <div class="main-header-two__top-left">
                            <div class="main-header-two__social-links">
                                <ul class="clearfix">
                                    <li><a href="#"><span class="icon-facebook-app-symbol"></span></a></li>
                                    <li><a href="#"><span class="icon-twitter"></span></a></li>
                                    <li><a href="#"><span class="icon-pinterest"></span></a></li>
                                    <li><a href="#"><span class="icon-instagram"></span></a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="main-header-two__top-right">
                            <div class="main-header-two__top-contact">
                                <ul class="main-header-two__top-contact-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-telephone-call"></span>
                                        </div>

                                        <div class="text-box">
                                            <p><a href="tel:000123453210000">+ 000-12345-32100-00</a></p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-email"></span>
                                        </div>

                                        <div class="text-box">
                                            <p><a href="mailto:yourmail@email.com">needhelp@company.com</a></p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-location"></span>
                                        </div>

                                        <div class="text-box">
                                            <p>80 Broklyn Golden Street USA</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Main Header Two Top-->

            <!--Start Main Header Two Bottom-->
            <div class="main-header-two__bottom">
                <div class="main-header-two__bottom-inner">
                    <nav class="main-menu main-menu-one">
                        <div class="main-menu__wrapper clearfix">
                            <div class="auto-container">
                                <div class="main-menu__wrapper-inner">
                                    <div class="container">
                                        <div class="main-menu__wrapper-inner-box">
                                            <div class="main-header-two__bottom-left">
                                                <div class="logo-box">
                                                    <a href="index.php"><img src="assets/images/resources/logo-1.png"
                                                            alt="#"></a>
                                                </div>
                                            </div>

                                            <div class="main-header-two__bottom-middle">
                                                <div class="main-menu-box">
                                                    <a href="#" class="mobile-nav__toggler">
                                                        <i class="fa fa-bars"></i>
                                                    </a>

                                                    <?php require_once('parts/header/menu.php'); ?>
                                                </div>
                                            </div>

                                            <div class="main-header-two__bottom-right">
                                                <div class="btn-box">
                                                    <a href="contact.php">Book an Appointment</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            <!--End Main Header Two Bottom-->
        </header>
        <!--End Main Header Two-->

        <div class="stricky-header stricky-header--two stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->