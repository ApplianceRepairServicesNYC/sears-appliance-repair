<!--Start Main Header Three-->
<header class="main-header main-header-three">

<!--Start Main Header Three Top-->
<div class="main-header-three__top">
    <div class="auto-container">
        <div class="main-header-three__top-inner">
            <div class="main-header-three__top-left">
                <div class="main-header-three__social-links">
                    <ul class="clearfix">
                        <li><a href="#"><span class="icon-facebook-app-symbol"></span></a></li>
                        <li><a href="#"><span class="icon-twitter"></span></a></li>
                        <li><a href="#"><span class="icon-pinterest"></span></a></li>
                        <li><a href="#"><span class="icon-instagram"></span></a></li>
                    </ul>
                </div>

                <div class="main-header-three__top-left-text">
                    <p>Mon-Fri : 9am to 6pm / Sat : 9am to 5pm</p>
                </div>
            </div>

            <div class="main-header-three__top-right">
                <div class="header-search-box">
                    <a href="#" class="main-menu__search search-toggler icon-search-interface-symbol">
                    </a>
                </div>

                <div class="main-header-three__top-right-icon">
                    <span class="icon-calculator"></span>
                </div>

                <div class="main-header-three__top-location">
                    <div class="icon-box">
                        <span class="icon-placeholder"></span>
                    </div>

                    <div class="content-box">
                        <p>Company Location</p>
                        <h3>Integer Rd, LA 082
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End Main Header Three Top-->

<!--Start Main Header Three Bottom-->
<div class="main-header-three__bottom">
    <div class="main-header-three__bottom-inner">
        <nav class="main-menu main-menu-one">
            <div class="main-menu__wrapper clearfix">
                <div class="auto-container">
                    <div class="main-menu__wrapper-inner">

                        <div class="main-header-three__bottom-left">
                            <div class="logo-box">
                                <a href="index.php"><img src="assets/images/resources/logo-3.png"
                                        alt="#"></a>
                            </div>
                        </div>

                        <div class="main-header-three__bottom-middle">
                            <div class="main-menu-box">
                                <a href="#" class="mobile-nav__toggler">
                                    <i class="fa fa-bars"></i>
                                </a>

                                <?php require_once('parts/header/menu.php'); ?>
                            </div>
                        </div>

                        <div class="main-header-three__bottom-right">
                            <div class="icon-box">
                                <span class="icon-ringing"></span>
                            </div>

                            <div class="content-box">
                                <p>Make a Call</p>
                                <a href="tel:23345678901">(+233) 456 789 01</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</div>
<!--End Main Header Three Bottom-->
</header>
<!--End Main Header Three-->

<div class="stricky-header stricky-header--two stricked-menu main-menu">
<div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->