<!--Start Main Header One-->
<header class="main-header main-header-one">

<!--Start Main Header One Top-->
<div class="main-header-one__top">
    <div class="auto-container">
        <div class="main-header-one__top-inner">
            <div class="main-header-one__top-left">
                <p>Mon-Fri : 9am to 6pm / Sat : 9am to 5pm</p>
            </div>

            <div class="main-header-one__top-middle">
                <div class="btn-box">
                    <a class="thm-btn" href="contact.php">
                        <span class="txt">Discover More</span>
                    </a>
                </div>
            </div>

            <div class="main-header-one__top-right">
                <div class="main-header-one__top-right-inner">
                    <div class="header-social-links">
                        <ul>
                            <li><a href="#"><span class="icon-facebook-app-symbol"></span></a></li>
                            <li><a href="#"><span class="icon-twitter"></span></a></li>
                            <li><a href="#"><span class="icon-pinterest"></span></a></li>
                            <li><a href="#"><span class="icon-instagram"></span></a></li>
                        </ul>
                    </div>

                    <div class="side-content-button-box">
                        <div class="side-content-button">
                            <a class="navSidebar-button" href="#">
                                <span class="decor"></span>
                                <span class="decor style2"></span>
                                <span class="decor"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End Main Header One Top-->

<!--Start Main Header One Bottom-->
<div class="main-header-one__bottom">
    <div class="main-header-one__bottom-inner">
        <nav class="main-menu main-menu-one">
            <div class="main-menu__wrapper clearfix">
                <div class="auto-container">
                    <div class="main-menu__wrapper-inner">

                        <div class="main-header-one__bottom-left">
                            <div class="logo-box">
                                <a href="index.php"><img src="assets/images/resources/logo-1.png"
                                        alt="#"></a>
                            </div>
                        </div>

                        <div class="main-header-one__bottom-middle">
                            <div class="main-menu-box">
                                <a href="#" class="mobile-nav__toggler">
                                    <i class="fa fa-bars"></i>
                                </a>

                                <?php require_once('parts/header/menu.php'); ?>
                            </div>
                        </div>

                        <div class="main-header-one__bottom-right">
                            <div class="header-search-box">
                                <a href="#"
                                    class="main-menu__search search-toggler icon-search-interface-symbol">
                                </a>
                            </div>

                            <div class="header-contact-box">
                                <div class="icon-box">
                                    <span class="icon-chatting"></span>
                                </div>

                                <div class="text-box">
                                    <p>Call Anytime</p>
                                    <a href="tel:926668880000">92 666 888 0000</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </nav>
    </div>
</div>
<!--End Main Header One Bottom-->
</header>
<!--End Main Header One-->

<div class="stricky-header stricky-header--one stricked-menu main-menu">
<div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->