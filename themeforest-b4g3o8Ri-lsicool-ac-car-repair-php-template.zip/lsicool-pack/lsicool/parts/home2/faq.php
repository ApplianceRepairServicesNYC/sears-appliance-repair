<!--Start Faq Two-->
<section class="faq-two">
            <div class="shape3 rotate-me"><img src="assets/images/shapes/pricing-v2-shape1.png" alt="#"></div>
            <div class="container">
                <div class="row">
                    <!--Start Faq Two Img-->
                    <div class="col-xl-5">
                        <div class="faq-two__img wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1500ms">
                            <div class="inner">
                                <div class="shape1"><img src="assets/images/shapes/faq-v2-shape1.png" alt=""></div>
                                <div class="shape2"></div>
                                <img src="assets/images/resources/faq-v2-img1.jpg" alt="#">

                                <div class="content-box">
                                    <div class="icon-box">
                                        <span class="icon-phone-call"></span>
                                    </div>
                                    <div class="text-box">
                                        <p>Call Anytime</p>
                                        <h3><a href="tel:13077760608">+ 1 (307) 776-0608</a></h3>
                                    </div>
                                </div>
                                <div class="faq-two__icon">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="faq-two__btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Faq Two Img-->

                    <!--Start Faq Two Accordion-->
                    <div class="col-xl-7">
                        <div class="faq-two__accordion">
                            <div class="sec-title style2">
                                <div class="sec-title__tagline">
                                    <h6>Have a Question</h6>
                                </div>
                                <h2 class="sec-title__title">Frequently asked questions</h2>
                            </div>

                            <ul class="accordion-box">

                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <div class="icon-outer">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                        <h3>
                                            Why should i choose autofix car service ?
                                        </h3>
                                    </div>
                                    <div class="acc-content">
                                        <p>Dolor amety consectetur notted tempors incididunt labore dolore utn
                                            magna alique mauris id auctor donec atestes ligulea kucacuses
                                            ruberate to bentonner thr rong position.
                                        </p>
                                    </div>
                                </li>

                                <li class="accordion block active-block">
                                    <div class="acc-btn active">
                                        <div class="icon-outer">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                        <h3>
                                            How to book a car service with autofix
                                        </h3>
                                    </div>
                                    <div class="acc-content current">
                                        <p>Dolor amety consectetur notted tempors incididunt labore dolore utn
                                            magna alique mauris id auctor donec atestes ligulea kucacuses
                                            ruberate to bentonner thr rong position.
                                        </p>
                                    </div>
                                </li>

                                <li class="accordion block mb30">
                                    <div class="acc-btn">
                                        <div class="icon-outer">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                        <h3>
                                            Traditional auto repair shops ?
                                        </h3>
                                    </div>
                                    <div class="acc-content">
                                        <p>Dolor amety consectetur notted tempors incididunt labore dolore utn
                                            magna alique mauris id auctor donec atestes ligulea kucacuses
                                            ruberate to bentonner thr rong position.
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Faq Two Accordion-->
                </div>
            </div>
        </section>
        <!--End Faq Two-->