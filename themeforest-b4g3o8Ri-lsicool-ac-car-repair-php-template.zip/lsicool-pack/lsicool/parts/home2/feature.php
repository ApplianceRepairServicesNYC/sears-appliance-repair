<!--Start Features Two -->
<section class="features-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="features-two__inner">
                            <div class="owl-carousel owl-theme thm-owl__carousel features-two__carousel"
                                data-owl-options='{
                                    "loop": true,
                                    "autoplay": true,
                                    "margin": 0,
                                    "nav": false,
                                    "dots": false,
                                    "smartSpeed": 500,
                                    "autoplayTimeout": 10000,
                                    "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-next\"></span>"],
                                    "responsive": {
                                            "0": {
                                                "items": 4
                                            },
                                            "768": {
                                                "items": 5
                                            },
                                            "992": {
                                                "items": 6
                                            },
                                            "1200": {
                                                "items": 7
                                            }
                                        }
                                    }'>
                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-coffee-cup"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Cup of coffee <br>
                                                & wi-fi</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-garage"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Vehicle drop off <br>
                                                & pickup</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-car-repair"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Shuttle Service <br>
                                                Available</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-badge"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">2 Years miles <br>
                                                warranty</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-trophy"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Free vacuum & <br>
                                                car wash</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-team"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Total of team <br>
                                                members</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->

                                <!--Start Features Two Single-->
                                <div class="features-two__single text-center">
                                    <div class="icon-box">
                                        <span class="icon-report"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2><a href="cooling-services.php">Financing of <br>
                                                available</a></h2>
                                    </div>
                                </div>
                                <!--End Features Two Single-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Features Two -->