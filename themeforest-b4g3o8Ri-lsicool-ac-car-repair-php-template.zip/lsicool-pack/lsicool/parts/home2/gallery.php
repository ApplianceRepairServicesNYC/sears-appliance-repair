<!--Start Gallery Two-->
<section class="gallery-two">
            <div class="container">
                <div class="gallery-two__top">
                    <div class="sec-title style2">
                        <div class="sec-title__tagline">
                            <h6>Case Study</h6>
                        </div>
                        <h2 class="sec-title__title">Recently work gallery</h2>
                    </div>

                    <div class="gallery-two__top-text">
                        <p>Dolor amety consectetur notted tempors incididunt labore
                            dolore utn magna alique mauris id auctor donec atestes
                            ligulea kucacuse.</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12">
                        <div class="gallery-two__inner">
                            <div class="owl-carousel owl-theme thm-owl__carousel gallery-two__carousel"
                                data-owl-options='{
                                    "loop": true,
                                    "autoplay": true,
                                    "margin": 30,
                                    "nav": false,
                                    "dots": false,
                                    "smartSpeed": 500,
                                    "autoplayTimeout": 10000,
                                    "navText": ["<span class=\"icon-right-arrow2\"></span>","<span class=\"icon-right-arrow21\"></span>"],
                                    "responsive": {
                                            "0": {
                                                "items": 1
                                            },
                                            "768": {
                                                "items": 1
                                            },
                                            "992": {
                                                "items": 1
                                            },
                                            "1200": {
                                                "items": 1
                                            }
                                        }
                                    }'>

                                <!--Start Gallery Two Single-->
                                <div class="gallery-two__single">
                                    <div class="gallery-two__single-inner">
                                        <div class="shape1"><img src="assets/images/shapes/gallery-v2-shape1.png"
                                                alt="#">
                                        </div>
                                        <img src="assets/images/gallery/gallery-v2-img1.jpg" alt="#">
                                        <div class="content-box">
                                            <div class="icon-box">
                                                <a href="project-details.php"><span
                                                        class="icon-right-arrow"></span></a>
                                            </div>
                                            <div class="text-box">
                                                <p>Engine Repar</p>
                                                <h2><a href="project-details.php">Preventative Mainter</a></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Two Single-->

                                <!--Start Gallery Two Single-->
                                <div class="gallery-two__single">
                                    <div class="gallery-two__single-inner">
                                        <div class="shape1"><img src="assets/images/shapes/gallery-v2-shape1.png"
                                                alt="#">
                                        </div>
                                        <img src="assets/images/gallery/gallery-v2-img2.jpg" alt="#">
                                        <div class="content-box">
                                            <div class="icon-box">
                                                <a href="project-details.php"><span
                                                        class="icon-right-arrow"></span></a>
                                            </div>
                                            <div class="text-box">
                                                <p>Engine Repar</p>
                                                <h2><a href="project-details.php">Preventative Mainter</a></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Two Single-->

                                <!--Start Gallery Two Single-->
                                <div class="gallery-two__single">
                                    <div class="gallery-two__single-inner">
                                        <div class="shape1"><img src="assets/images/shapes/gallery-v2-shape1.png"
                                                alt="#">
                                        </div>
                                        <img src="assets/images/gallery/gallery-v2-img3.jpg" alt="#">
                                        <div class="content-box">
                                            <div class="icon-box">
                                                <a href="project-details.php"><span
                                                        class="icon-right-arrow"></span></a>
                                            </div>
                                            <div class="text-box">
                                                <p>Engine Repar</p>
                                                <h2><a href="project-details.php">Preventative Mainter</a></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Two Single-->

                                <!--Start Gallery Two Single-->
                                <div class="gallery-two__single">
                                    <div class="gallery-two__single-inner">
                                        <div class="shape1"><img src="assets/images/shapes/gallery-v2-shape1.png"
                                                alt="#">
                                        </div>
                                        <img src="assets/images/gallery/gallery-v2-img4.jpg" alt="#">
                                        <div class="content-box">
                                            <div class="icon-box">
                                                <a href="project-details.php"><span
                                                        class="icon-right-arrow"></span></a>
                                            </div>
                                            <div class="text-box">
                                                <p>Engine Repar</p>
                                                <h2><a href="project-details.php">Preventative Mainter</a></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Two Single-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Gallery Two-->