<!--Start Counter Two-->
<section class="counter-two">
            <div class="container">
                <div class="row">
                    <!--Start Counter Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.1s">
                        <div class="counter-two__single text-center">
                            <div class="counter-two__single-number">
                                <h3>01</h3>
                            </div>

                            <div class="counter-two__single-icon">
                                <span class=" icon-maintenance-1"></span>
                            </div>

                            <div class="counter-two__single-title">
                                <h4>Expert <br>
                                    of Workers</h4>
                            </div>

                            <div class="counter-two__single-bottom">
                                <h2><span class="odometer" data-count="1.5">00</span> <span class="k">k</span>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <!--End Counter Two Single-->

                    <!--Start Counter Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.2s">
                        <div class="counter-two__single style2 text-center">
                            <div class="counter-two__single-bg"
                                style="background-image: url(assets/images/resources/counter-v2-img1.jpg);"></div>
                            <div class="counter-two__single-number">
                                <h3>02</h3>
                            </div>

                            <div class="counter-two__single-icon">
                                <span class="icon-trophy"></span>
                            </div>

                            <div class="counter-two__single-title">
                                <h4>Award <br>
                                    Recieveds</h4>
                            </div>

                            <div class="counter-two__single-bottom">
                                <h2><span class="odometer" data-count="423">00</span> <span class="k">+</span>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <!--End Counter Two Single-->

                    <!--Start Counter Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.3s">
                        <div class="counter-two__single text-center">
                            <div class="counter-two__single-number">
                                <h3>03</h3>
                            </div>

                            <div class="counter-two__single-icon">
                                <span class="icon-customer-review-1"></span>
                            </div>

                            <div class="counter-two__single-title">
                                <h4>Happy <br>
                                    Customers</h4>
                            </div>

                            <div class="counter-two__single-bottom">
                                <h2><span class="odometer" data-count="97">00</span> <span class="k">%</span>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <!--End Counter Two Single-->

                    <!--Start Counter Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.4s">
                        <div class="counter-two__single style2 text-center">
                            <div class="counter-two__single-bg"
                                style="background-image: url(assets/images/resources/counter-v2-img2.jpg);"></div>
                            <div class="counter-two__single-number">
                                <h3>04</h3>
                            </div>

                            <div class="counter-two__single-icon">
                                <span class="icon-satisfaction"></span>
                            </div>

                            <div class="counter-two__single-title">
                                <h4>Project <br>
                                    Completed</h4>
                            </div>

                            <div class="counter-two__single-bottom">
                                <h2><span class="odometer" data-count="2.4">00</span> <span class="k">k</span>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <!--End Counter Two Single-->
                </div>
            </div>
        </section>
        <!--End Counter Two-->