<!--Start Brand Two-->
<section class="brand-two">
            <div class="container">
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 5, "autoplay": { "delay": 5000 }, "breakpoints": {
                                    "0": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 1
                                    },
                                    "375": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 1
                                    },
                                    "575": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 2
                                    },
                                    "767": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 3
                                    },
                                    "991": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 4
                                    },
                                    "1199": {
                                        "spaceBetween": 30,
                                        "slidesPerView": 5
                                    }
                                }}'>
                    <div class="swiper-wrapper">


                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img1.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img2.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img3.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img4.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img5.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img1.png" alt="#">
                        </div>


                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img2.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img3.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img4.png" alt="#">
                        </div>

                        <div class="swiper-slide">
                            <img src="assets/images/brand/brand-v2-img5.png" alt="#">
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <!--End Brand Two -->