<!--Start Video One-->
<section class="video-one">
            <div class="shape1"><img src="assets/images/shapes/video-v1-shape1.png" alt="#"></div>
            <div class="video-one__bg" style="background-image: url(assets/images/backgrounds/video-v1-bg.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="video-one__inner">
                            <div class="video-one__left">
                                <div class="video-one__icon">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="video-one__btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>

                                <div class="text-box">
                                    <p><a href="https://www.youtube.com/watch?v=pVE92TNDwUk" class="video-popup"><span
                                                class="icon-right-arrow"></span> Watch the Video</a></p>
                                </div>
                            </div>

                            <div class="video-one__right">
                                <h2>Getting the job done <span>wherever</span> <br>
                                    however positive matters</h2>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Video One-->