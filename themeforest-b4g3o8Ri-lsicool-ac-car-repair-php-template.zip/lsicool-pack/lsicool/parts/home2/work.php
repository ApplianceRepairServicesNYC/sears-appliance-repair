<!--Start Work One-->
<section class="work-one">
            <div class="shape1 float-bob-y"><img src="assets/images/shapes/work-v1-shape1.png" alt="#"></div>
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>How it's work</h6>
                    </div>
                    <h2 class="sec-title__title">Standard working process</h2>
                </div>
                <ul class="row">
                    <!--Start Work One Single-->
                    <li class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1000ms">
                        <div class="work-one__single">
                            <div class="icon-box">
                                <a href="cooling-services.php"><span class="icon-chevron"></span></a>
                            </div>
                            <div class="work-one__single-img">
                                <div class="work-one__single-img-inner">
                                    <img src="assets/images/resources/work-v1-img1.jpg" alt="#">
                                    <div class="number-box">
                                        01
                                    </div>
                                </div>
                                <div class="icon-box">
                                    <span class="icon-checklist"></span>
                                </div>
                            </div>

                            <div class="work-one__single-content text-center">
                                <h2><a href="cooling-services.php">Prepare Solution</a></h2>
                                <p> Utn magna alique mauris auctor biggest on <br>
                                    donec ateste ligulea kuceus</p>
                            </div>
                        </div>
                    </li>
                    <!--End Work One Single-->

                    <!--Start Work One Single-->
                    <li class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="200ms" data-wow-duration="1000ms">
                        <div class="work-one__single">
                            <div class="icon-box">
                                <a href="cooling-services.php"><span class="icon-chevron"></span></a>
                            </div>
                            <div class="work-one__single-img">
                                <div class="work-one__single-img-inner">
                                    <img src="assets/images/resources/work-v1-img2.jpg" alt="#">
                                    <div class="number-box">
                                        02
                                    </div>
                                </div>
                                <div class="icon-box">
                                    <span class="icon-idea"></span>
                                </div>
                            </div>

                            <div class="work-one__single-content text-center">
                                <h2><a href="cooling-services.php">Identify Issues</a></h2>
                                <p> Utn magna alique mauris auctor biggest on <br>
                                    donec ateste ligulea kuceus</p>
                            </div>

                        </div>
                    </li>
                    <!--End Work One Single-->

                    <!--Start Work One Single-->
                    <li class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1000ms">
                        <div class="work-one__single">
                            <div class="work-one__single-img">
                                <div class="work-one__single-img-inner">
                                    <img src="assets/images/resources/work-v1-img3.jpg" alt="#">
                                    <div class="number-box">
                                        03
                                    </div>
                                </div>
                                <div class="icon-box">
                                    <span class="icon-sketch"></span>
                                </div>
                            </div>

                            <div class="work-one__single-content text-center">
                                <h2><a href="cooling-services.php">Working on this</a></h2>
                                <p> Utn magna alique mauris auctor biggest on <br>
                                    donec ateste ligulea kuceus</p>
                            </div>

                        </div>
                    </li>
                    <!--End Work One Single-->
                </ul>
            </div>
        </section>
        <!--End Work One-->