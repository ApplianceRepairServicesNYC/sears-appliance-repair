<!--Start Features Three -->
<section class="features-three">
            <div class="shape1"><img src="assets/images/shapes/features-v3-shape1.png" alt="#"></div>
            <div class="shape2"><img src="assets/images/shapes/features-v3-shape2.png" alt="#"></div>
            <div class="container">
                <div class="features-three__inner">
                    <div class="row">
                        <!--Start Features Three Single-->
                        <div class="col-xl-6 col-lg-6 wow animated fadeInUp" data-wow-delay="0.1s">
                            <div class="features-three__single">
                                <div class="features-three__single-inner">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <span class="icon-technician"></span>
                                        </div>
                                        <div class="border-box"></div>
                                    </div>

                                    <div class="content-box">
                                        <span>Mechanic</span>
                                        <h2><a href="cooling-services.php">Professtional Expert</a></h2>
                                        <p>Dolor amety consectetur notted tempor incidunt <br>
                                            labore donec atestes ligula lacus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Features Three Single-->

                        <!--Start Features Three Single-->
                        <div class="col-xl-6 col-lg-6 wow animated fadeInUp" data-wow-delay="0.2s">
                            <div class="features-three__single">
                                <div class="features-three__single-inner">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <span class="icon-satisfaction"></span>
                                        </div>
                                        <div class="border-box"></div>
                                    </div>

                                    <div class="content-box">
                                        <span>Mechanic</span>
                                        <h2><a href="cooling-services.php">Customer Satisfaction</a></h2>
                                        <p>Dolor amety consectetur notted tempor incidunt <br>
                                            labore donec atestes ligula lacus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Features Three Single-->
                    </div>
                </div>
            </div>
        </section>
        <!--End Features Three -->