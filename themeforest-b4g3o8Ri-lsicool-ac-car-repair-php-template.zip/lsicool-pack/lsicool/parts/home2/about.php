<!--Start About Two -->
<section class="about-two">
            <div class="shape3 float-bob-y"><img src="assets/images/shapes/about-v2-shape3.png" alt="#"></div>
            <div class="container">
                <div class="row">
                    <!--Start About Two Img-->
                    <div class="col-xl-6">
                        <div class="about-two__img">
                            <div class="about-two__img-inner">
                                <img src="assets/images/about/about-v2-img1.jpg" alt="#">
                                <div class="experience-box">
                                    <h2>12+ Years Experience</h2>
                                </div>
                            </div>

                            <div class="about-two__img-text">
                                <div class="shape1"><img src="assets/images/shapes/about-v2-shape1.png" alt="#"></div>
                                <h2> <span>100%</span> Satisfaction <br>
                                    Guarantee</h2>
                            </div>
                        </div>
                    </div>
                    <!--End About Two Img-->

                    <!--Start About Two Content-->
                    <div class="col-xl-6">
                        <div class="about-two__content">
                            <div class="sec-title style2">
                                <div class="sec-title__tagline">
                                    <h6>About Company</h6>
                                </div>
                                <h2 class="sec-title__title">We keep your car running <br>
                                    newer longer.</h2>
                            </div>

                            <div class="about-two__content-text">
                                <p>Dolor amety consectetur notted tempors incididunt labore dolore utn <br>
                                    magna alique mauris id auctor donec atestes ligula lacus.</p>
                            </div>

                            <div class="about-two__content-bottom">
                                <div class="row">
                                    <div class="col-xl-8 col-lg-8 col-md-8">
                                        <div class="about-two__content-bottom-content">
                                            <div class="single-box">
                                                <div class="inner">
                                                    <div class="icon-box">
                                                        <span class="icon-checklist"></span>
                                                    </div>

                                                    <div class="content-box">
                                                        <h2>Confirm for Services</h2>
                                                        <p>Magna alique mauris auctor donec <br>
                                                            atestes ligula lacus.</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="single-box mt">
                                                <div class="inner">
                                                    <div class="icon-box">
                                                        <span class="icon-car-repair-1"></span>
                                                    </div>

                                                    <div class="content-box">
                                                        <h2>Make an Appointment</h2>
                                                        <p>Magna alique mauris auctor donec <br>
                                                            atestes ligula lacus.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-4 col-lg-4 col-md-4">
                                        <div class="about-two__content-bottom-img">
                                            <div class="about-two__content-bottom-img-inner">
                                                <div class="shape1 float-bob-y"><img
                                                        src="assets/images/shapes/about-v2-shape2.png" alt="#"></div>
                                                <img src="assets/images/about/about-v2-img2.jpg" alt="#">

                                                <div class="content-box">
                                                    <div class="about-two__icon">
                                                        <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                                            class="about-two__btn video-popup">
                                                            <span class="icon-play"></span>
                                                        </a>
                                                    </div>
                                                    <p>Watch the Video</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End About Two Content-->
                </div>
            </div>
        </section>
        <!--End About Two -->