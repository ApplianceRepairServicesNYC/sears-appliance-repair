<!--Start Blog Two-->
<section class="blog-two">
            <div class="shape1 rotate-me"><img src="assets/images/shapes/blog-v2-shape1.png" alt="#"></div>
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Company News</h6>
                    </div>
                    <h2 class="sec-title__title">Latest News & Inspirational</h2>
                </div>
                <div class="row">
                    <!--Start Blog Two Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="blog-two__single">
                            <div class="blog-two__single-content">
                                <p>Installations</p>
                                <h2><a href="blog-details.php">Embrace lot of driven activities <br>
                                        through user</a></h2>
                                <div class="btn-box">
                                    <a href="blog-details.php">Read More <span class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="blog-two__single-img">
                                <img src="assets/images/blog/blog-v2-img1.jpg" alt="#">
                                <div class="date-box">
                                    26 Feb 2023
                                </div>
                                <div class="icon-box">
                                    <a href="blog-details.php"><span class="icon-link"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Blog Two Single-->

                    <!--Start Blog Two Single-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="100ms"
                        data-wow-duration="1500ms">
                        <div class="blog-two__single">
                            <div class="blog-two__single-content">
                                <p>Installations</p>
                                <h2><a href="blog-details.php">Orient value after functional best <br>
                                        practices timely</a></h2>
                                <div class="btn-box">
                                    <a href="blog-details.php">Read More <span class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="blog-two__single-img">
                                <img src="assets/images/blog/blog-v2-img2.jpg" alt="#">
                                <div class="date-box">
                                    03 Sep 2023
                                </div>
                                <div class="icon-box">
                                    <a href="blog-details.php"><span class="icon-link"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Blog Two Single-->

                    <!--Start Blog Two Right-->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="200ms"
                        data-wow-duration="1500ms">
                        <div class="blog-two__right">
                            <!--Start Blog Two Single-->
                            <div class="blog-two__single">
                                <div class="blog-two__single-content">
                                    <h2><a href="blog-details.php">Before the visiony tectural build <br>
                                            sticky handle car</a></h2>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More <span class="icon-right-arrow"></span></a>
                                        <div class="date-box2">
                                            <span>17 June 2023</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Two Single-->

                            <!--Start Blog Two Single-->
                            <div class="blog-two__single">
                                <div class="blog-two__single-content">
                                    <h2><a href="blog-details.php">Monetize user centric source & <br>
                                            user mindshare</a></h2>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More <span class="icon-right-arrow"></span></a>
                                        <div class="date-box2">
                                            <span>17 June 2023</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Two Single-->

                            <!--Start Blog Two Single-->
                            <div class="blog-two__single">
                                <div class="blog-two__single-content">
                                    <h2><a href="blog-details.php">Give your small car the horn it <br>
                                            deserves</a></h2>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More <span class="icon-right-arrow"></span></a>
                                        <div class="date-box2">
                                            <span>17 June 2023</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Two Single-->
                        </div>
                    </div>
                    <!--End Blog Two Right-->
                </div>
            </div>
        </section>
        <!--End Blog Two-->