<!--Start Main Slider Two-->
<section class="main-slider main-slider-two">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5000
                }}'>
                <div class="swiper-wrapper">

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v2-img3.jpg)">
                        </div>
                        <div class="shape1"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape1.png"
                                alt="#"></div>
                        <div class="shape2"><img class="rotate-me" src="assets/images/shapes/slider-v2-shape2.png"
                                alt="#"></div>
                        <div class="shape3"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape3.png"
                                alt="#"></div>

                        <div class="container">
                            <div class="main-slider-two__content">
                                <div class="title">
                                    <h2>Provide Best Repair <br>
                                        Services</h2>
                                </div>

                                <div class="text-box">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the
                                        majority have <br> suffered alteration in some form, by injected humour,</p>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v2-img1.jpg)">
                        </div>
                        <div class="shape1"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape1.png"
                                alt="#"></div>
                        <div class="shape2"><img class="rotate-me" src="assets/images/shapes/slider-v2-shape2.png"
                                alt="#"></div>
                        <div class="shape3"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape3.png"
                                alt="#"></div>

                        <div class="container">
                            <div class="main-slider-two__content">
                                <div class="title">
                                    <h2>Provide Best Repair <br>
                                        Services</h2>
                                </div>

                                <div class="text-box">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the
                                        majority have <br> suffered alteration in some form, by injected humour,</p>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v2-img2.jpg)">
                        </div>
                        <div class="shape1"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape1.png"
                                alt="#"></div>
                        <div class="shape2"><img class="rotate-me" src="assets/images/shapes/slider-v2-shape2.png"
                                alt="#"></div>
                        <div class="shape3"><img class="float-bob-y" src="assets/images/shapes/slider-v2-shape3.png"
                                alt="#"></div>

                        <div class="container">
                            <div class="main-slider-two__content">
                                <div class="title">
                                    <h2>Provide Best Repair <br>
                                        Services</h2>
                                </div>

                                <div class="text-box">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the
                                        majority have <br> suffered alteration in some form, by injected humour,</p>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->
                </div>

                <!-- If we need navigation buttons -->
                <div class="swiper-pagination" id="main-slider-pagination"></div>

            </div>
        </section>
        <!--End Main Slider Two-->