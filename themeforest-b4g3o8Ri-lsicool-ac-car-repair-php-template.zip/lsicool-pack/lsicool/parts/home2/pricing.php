<!--Start Pricing Two-->
<section class="pricing-two">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Pricing Plan</h6>
                    </div>
                    <h2 class="sec-title__title">The best choices</h2>
                </div>
                <div class="row">
                    <!--Start Pricing Two Single-->
                    <div class="col-xl-4 col-lg-4 wow animated fadeInUp" data-wow-delay="0.1s">
                        <div class="pricing-two__single">
                            <div class="pricing-two__single-inner">
                                <div class="pricing-two__single-bg"
                                    style="background-image: url(assets/images/resources/pricing-v2-img.jpg);"></div>

                                <div class="table-header">
                                    <div class="icon-box">
                                        <span class="icon-15"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2>$23</h2>
                                        <p>Starting Package</p>
                                    </div>
                                </div>

                                <div class="table-content">
                                    <ul>
                                        <li>
                                            <p>Providing solutions</p>
                                        </li>

                                        <li>
                                            <p>Rims & tire change</p>
                                        </li>

                                        <li>
                                            <p>Wipe all surfaces</p>
                                        </li>

                                        <li>
                                            <p>Leather clean & dry</p>
                                        </li>

                                        <li>
                                            <p>Light carpet clean</p>
                                        </li>

                                        <li>
                                            <p>24/7 skilled support</p>
                                        </li>
                                    </ul>
                                </div>

                                <div class="table-footer">
                                    <div class="btn-box">
                                        <a class="thm-btn" href="#">
                                            <span class="txt">Order Now</span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Pricing Two Single-->

                    <!--Start Pricing Two Single-->
                    <div class="col-xl-4 col-lg-4 wow animated fadeInUp" data-wow-delay="0.3s">
                        <div class="pricing-two__single">
                            <div class="pricing-two__single-inner">
                                <div class="pricing-two__single-bg"
                                    style="background-image: url(assets/images/resources/pricing-v2-img.jpg);"></div>

                                <div class="table-header">
                                    <div class="icon-box">
                                        <span class="icon-15"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2>$33</h2>
                                        <p>Bronze Package</p>
                                    </div>
                                </div>

                                <div class="table-content">
                                    <ul>
                                        <li>
                                            <p>Providing solutions</p>
                                        </li>

                                        <li>
                                            <p>Rims & tire change</p>
                                        </li>

                                        <li>
                                            <p>Wipe all surfaces</p>
                                        </li>

                                        <li>
                                            <p>Leather clean & dry</p>
                                        </li>

                                        <li>
                                            <p>Light carpet clean</p>
                                        </li>

                                        <li>
                                            <p>24/7 skilled support</p>
                                        </li>
                                    </ul>
                                </div>

                                <div class="table-footer">
                                    <div class="btn-box">
                                        <a class="thm-btn" href="#">
                                            <span class="txt">Order Now</span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Pricing Two Single-->

                    <!--Start Pricing Two Single-->
                    <div class="col-xl-4 col-lg-4 wow animated fadeInUp" data-wow-delay="0.5s">
                        <div class="pricing-two__single">
                            <div class="pricing-two__single-inner">
                                <div class="pricing-two__single-bg"
                                    style="background-image: url(assets/images/resources/pricing-v2-img.jpg);"></div>

                                <div class="table-header">
                                    <div class="icon-box">
                                        <span class="icon-15"></span>
                                    </div>

                                    <div class="title-box">
                                        <h2>$43</h2>
                                        <p>Premium Package</p>
                                    </div>
                                </div>

                                <div class="table-content">
                                    <ul>
                                        <li>
                                            <p>Providing solutions</p>
                                        </li>

                                        <li>
                                            <p>Rims & tire change</p>
                                        </li>

                                        <li>
                                            <p>Wipe all surfaces</p>
                                        </li>

                                        <li>
                                            <p>Leather clean & dry</p>
                                        </li>

                                        <li>
                                            <p>Light carpet clean</p>
                                        </li>

                                        <li>
                                            <p>24/7 skilled support</p>
                                        </li>
                                    </ul>
                                </div>

                                <div class="table-footer">
                                    <div class="btn-box">
                                        <a class="thm-btn" href="#">
                                            <span class="txt">Order Now</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Pricing Two Single-->
                </div>
            </div>
        </section>
        <!--End Pricing Two-->