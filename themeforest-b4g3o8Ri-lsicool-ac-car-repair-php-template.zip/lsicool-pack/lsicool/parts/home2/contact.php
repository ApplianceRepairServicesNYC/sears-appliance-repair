<!--Start Contact One-->
<section class="contact-one">
            <div class="contact-one__bg" style="background-image: url(assets/images/backgrounds/contact-v1-bg.jpg);">
            </div>
            <div class="shape2 float-bob-y"><img src="assets/images/shapes/contact-v1-shape2.png" alt="#"></div>
            <div class="container">
                <div class="cta-one">
                    <div class="cta-one__inner">
                        <div class="cta-one__content">
                            <div class="icon-box">
                                <span class="icon-message"></span>
                            </div>

                            <div class="title-box">
                                <h2>Looking for a quality architect <br>
                                    for your project ?</h2>
                            </div>
                        </div>

                        <div class="cta-one__btn">
                            <a href="contact.php">Get a free quote</a>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!--Start Contact One Content-->
                    <div class="col-xl-5">
                        <div class="contact-one__content">
                            <div class="sec-title style2">
                                <div class="sec-title__tagline">
                                    <h6>Contact Us</h6>
                                </div>
                                <h2 class="sec-title__title">We are always ready <br>
                                    to help you</h2>
                            </div>

                            <div class="contact-one__content-text">
                                <p>Dolor amety consectetur notted tempor incidid labore
                                    dolore magna alique mauris auctor donec atestes
                                    ligulea kucacuse.</p>
                            </div>
                        </div>
                    </div>
                    <!--End Contact One Content-->

                    <!--Start Contact One Form-->
                    <div class="col-xl-7">
                        <div class="contact-one__form">
                            <div class="shape1 float-bob-y"><img src="assets/images/shapes/contact-v1-shape1.png"
                                    alt="#"></div>
                            <form id="contact-form" name="contact_form" class="default-form2"
                                action="https://unicktheme.com/lsicool/assets/inc/sendmail.php" method="post">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="input-box">
                                            <input type="text" name="form_name" value="" placeholder="Your Name"
                                                required="">
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="input-box">
                                            <input type="email" name="form_email" value="" placeholder="Email Address"
                                                required="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xl-4 col-lg-4 col-md-4">
                                        <div class="input-box">
                                            <input type="text" name="form_subject" value="" placeholder="Select Date"
                                                id="datepicker">
                                        </div>
                                    </div>

                                    <div class="col-xl-4 col-lg-4 col-md-4">
                                        <div class="input-box">
                                            <input type="text" name="time" placeholder="Select time">
                                        </div>
                                    </div>

                                    <div class="col-xl-4 col-lg-4 col-md-4">
                                        <div class="input-box">
                                            <div class="select-box">
                                                <select class="selectmenu wide">
                                                    <option selected="selected">Select Categories</option>
                                                    <option>Categories 01</option>
                                                    <option>Categories 02</option>
                                                    <option>Categories 03</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="input-box">
                                            <textarea name="message" placeholder="Message"></textarea>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="contact-one__form-btn">
                                            <button class="thm-btn" type="submit" data-loading-text="Please wait...">
                                                <span class="txt">Send a Message</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--End Contact One Form-->
                </div>
            </div>
        </section>
        <!--End Contact One-->