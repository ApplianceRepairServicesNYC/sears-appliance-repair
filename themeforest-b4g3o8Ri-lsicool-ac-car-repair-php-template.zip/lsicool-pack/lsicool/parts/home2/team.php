<!--Start Team Two-->
<section class="team-two">
            <div class="shape1 float-bob-y"><img src="assets/images/shapes/gallery-v2-shape2.png" alt="#"></div>
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Our Team</h6>
                    </div>
                    <h2 class="sec-title__title">Meet the expert artists</h2>
                </div>
                <div class="row">
                    <!--Start Team Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                        <div class="team-two__single">
                            <div class="team-two__single-img">
                                <div class="inner">
                                    <img src="assets/images/team/team-v2-img1.jpg" alt="#">
                                </div>
                                <ul class="social-links clearfix">
                                    <li class="share"><a href="#"><span class="icon-share"></span></a>
                                        <ul class="social-links-inner">
                                            <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                            <li><a href="#"><i class="icon-twitter"></i></a>
                                            </li>
                                            <li><a href="#"><i class="icon-linkedin"></i></a></li>

                                            <li><a href="#"><i class="icon-dribbble"></i></a></li>

                                        </ul>
                                    </li>
                                </ul>

                                <div class="overlay-content text-center">
                                    <h2><a href="team-details.php">Rasonal Smith</a></h2>
                                    <p>Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Team Two Single-->

                    <!--Start Team Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6  wow fadeInDown" data-wow-delay=".3s">
                        <div class="team-two__single">
                            <div class="team-two__single-img">
                                <div class="inner">
                                    <img src="assets/images/team/team-v2-img2.jpg" alt="#">
                                </div>
                                <ul class="social-links clearfix">
                                    <li class="share"><a href="#"><span class="icon-share"></span></a>
                                        <ul class="social-links-inner">
                                            <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                            <li><a href="#"><i class="icon-twitter"></i></a>
                                            </li>
                                            <li><a href="#"><i class="icon-linkedin"></i></a></li>

                                            <li><a href="#"><i class="icon-dribbble"></i></a></li>

                                        </ul>
                                    </li>
                                </ul>
                                <div class="overlay-content text-center">
                                    <h2><a href="team-details.php">Rasonal Smith</a></h2>
                                    <p>Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Team Two Single-->

                    <!--Start Team Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                        <div class="team-two__single">
                            <div class="team-two__single-img">
                                <div class="inner">
                                    <img src="assets/images/team/team-v2-img3.jpg" alt="#">
                                </div>
                                <ul class="social-links clearfix">
                                    <li class="share"><a href="#"><span class="icon-share"></span></a>
                                        <ul class="social-links-inner">
                                            <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                            <li><a href="#"><i class="icon-twitter"></i></a>
                                            </li>
                                            <li><a href="#"><i class="icon-linkedin"></i></a></li>

                                            <li><a href="#"><i class="icon-dribbble"></i></a></li>

                                        </ul>
                                    </li>
                                </ul>
                                <div class="overlay-content text-center">
                                    <h2><a href="team-details.php">Rasonal Smith</a></h2>
                                    <p>Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Team Two Single-->

                    <!--Start Team Two Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInDown" data-wow-delay=".3s">
                        <div class="team-two__single">
                            <div class="team-two__single-img">
                                <div class="inner">
                                    <img src="assets/images/team/team-v2-img4.jpg" alt="#">
                                </div>
                                <ul class="social-links clearfix">
                                    <li class="share"><a href="#"><span class="icon-share"></span></a>
                                        <ul class="social-links-inner">
                                            <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                            <li><a href="#"><i class="icon-twitter"></i></a>
                                            </li>
                                            <li><a href="#"><i class="icon-linkedin"></i></a></li>

                                            <li><a href="#"><i class="icon-dribbble"></i></a></li>

                                        </ul>
                                    </li>
                                </ul>

                                <div class="overlay-content text-center">
                                    <h2><a href="team-details.php">Rasonal Smith</a></h2>
                                    <p>Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Team Two Single-->
                </div>
            </div>
        </section>
        <!--End Team Two-->