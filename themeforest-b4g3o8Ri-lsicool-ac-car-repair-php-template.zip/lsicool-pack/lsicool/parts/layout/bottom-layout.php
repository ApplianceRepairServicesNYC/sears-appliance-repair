</div><!-- /.page-wrapper -->


<?php require_once('parts/mobile-nav.php'); ?>
<?php require_once('parts/offcanvas.php'); ?>
<?php require_once('parts/search.php'); ?>
<?php require_once('parts/back-to-top.php'); ?>
<?php require_once('parts/script.php'); ?>
</body>

</html>