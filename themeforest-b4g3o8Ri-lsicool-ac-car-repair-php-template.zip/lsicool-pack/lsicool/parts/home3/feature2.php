<!--Start Features Five -->
<section class="features-five">
            <div class="container">
                <div class="features-five__inner clearfix">
                    <ul class="features-five__box clearfix">
                        <!--Start Features Five Single-->
                        <li class="wow animated fadeInUp" data-wow-delay="0.1s">
                            <div class="img-box">
                                <div class="inner">
                                    <div class="shape1"></div>
                                    <img src="assets/images/resources/features-v5-img1.png" alt="#">
                                </div>
                            </div>
                        </li>
                        <!--End Features Five Single-->

                        <!--Start Features Five Single-->
                        <li class="wow animated fadeInUp" data-wow-delay="0.2s">
                            <div class="img-box">
                                <div class="inner">
                                    <div class="shape1"></div>
                                    <img src="assets/images/resources/features-v5-img2.png" alt="#">
                                </div>
                            </div>
                        </li>
                        <!--End Features Five Single-->

                        <!--Start Features Five Single-->
                        <li class="wow animated fadeInUp" data-wow-delay="0.3s">
                            <div class="img-box">
                                <div class="inner">
                                    <div class="shape1"></div>
                                    <img src="assets/images/resources/features-v5-img3.png" alt="#">
                                </div>
                            </div>
                        </li>
                        <!--End Features Five Single-->

                        <!--Start Features Five Single-->
                        <li class="wow animated fadeInUp" data-wow-delay="0.4s">
                            <div class="img-box">
                                <div class="inner">
                                    <div class="shape1"></div>
                                    <img src="assets/images/resources/features-v5-img4.png" alt="#">
                                </div>
                            </div>
                        </li>
                        <!--End Features Five Single-->

                        <!--Start Features Five Single-->
                        <li class="wow animated fadeInUp" data-wow-delay="0.5s">
                            <div class="img-box">
                                <div class="inner">
                                    <div class="shape1"></div>
                                    <img src="assets/images/resources/features-v5-img5.png" alt="#">
                                </div>
                            </div>
                        </li>
                        <!--End Features Five Single-->

                    </ul>
                </div>
            </div>
        </section>
        <!--End Features Five -->