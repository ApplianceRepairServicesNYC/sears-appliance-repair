<!--Start Products One -->
<section class="product-one">
            <div class="shape1 float-bob-y"><img src="assets/images/shapes/product-v1-shape1.png" alt="#"></div>
            <div class="shape2 float-bob-y"><img src="assets/images/shapes/product-v1-shape1.png" alt="#"></div>
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Popular Products</h6>
                    </div>
                    <h2 class="sec-title__title">Browse our products</h2>
                </div>
                <div class="row">
                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.1s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Industry <br>
                                            air ventilation</a></h2>
                                    <p>$77.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img1.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.2s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Mutimedia <br>
                                            alarm devices</a></h2>
                                    <p>$89.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img2.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.3s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Industry <br>
                                            air ventilation</a></h2>
                                    <p>$21.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img3.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->

                    <!--Start Products One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow animated fadeInUp" data-wow-delay="0.4s">
                        <div class="product-one__single">
                            <div class="product-one__single-content">
                                <div class="product-one__single-content-btn">
                                    <div class="title">
                                        <h6><a href="#">Add To Cart</a></h6>
                                    </div>

                                    <div class="icon">
                                        <ul>
                                            <li><a href="#"><span class="icon-visibility eye"></span></a>
                                            </li>
                                            <li><a href="#"><span class="icon-heart"></span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="product-one__single-content-inner text-center">
                                    <h2><a href="#">Air conditioner <br>
                                            heat pump</a></h2>
                                    <p>$64.00</p>
                                    <div class="rating-box">
                                        <ul>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                            <li>
                                                <span class="icon-pointed-star"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="product-one__single-img">
                                <div class="inner">
                                    <img src="assets/images/shop/product-v1-img4.jpg" alt="#">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Products One Single-->
                </div>
            </div>
        </section>
        <!--End Products One -->