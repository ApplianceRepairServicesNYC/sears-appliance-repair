<!--Start Faq Three -->
<section class="faq-three">
            <div class="shape1"><img src="assets/images/shapes/faq-v3-shape1.png" alt=""></div>
            <div class="shape2 float-bob-y"><img src="assets/images/shapes/faq-v3-shape2.png" alt=""></div>
            <div class="container">
                <div class="row">
                    <!--Start Faq Three Accordion-->
                    <div class="col-xl-5">
                        <div class="faq-two__accordion style3">
                            <div class="sec-title style2">
                                <div class="sec-title__tagline">
                                    <h6>Faq</h6>
                                </div>
                                <h2 class="sec-title__title">Solutions for an every <br>
                                    repiar <span>problem</span></h2>
                            </div>

                            <ul class="accordion-box">

                                <li class="accordion block active-block">
                                    <div class="acc-btn active">
                                        <h3>
                                            When can i expect to see my credit score go up ?
                                        </h3>
                                    </div>
                                    <div class="acc-content current">
                                        <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                            dolore magna mauris id auctor donect atestes ligula kacuse for every
                                            resons credits to develop in level in the works process.
                                        </p>
                                    </div>
                                </li>

                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <h3>
                                            Can you remove anything from my credit report ?
                                        </h3>
                                    </div>
                                    <div class="acc-content">
                                        <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                            dolore magna mauris id auctor donect atestes ligula kacuse for every
                                            resons credits to develop in level in the works process.
                                        </p>
                                    </div>
                                </li>

                                <li class="accordion block mb0">
                                    <div class="acc-btn">
                                        <h3>
                                            Why do i need reports from all 3 credit bureaus ?
                                        </h3>
                                    </div>
                                    <div class="acc-content">
                                        <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                            dolore magna mauris id auctor donect atestes ligula kacuse for every
                                            resons credits to develop in level in the works process.
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Faq Three Accordion-->

                    <!--Start Faq Three Img-->
                    <div class="col-xl-7">
                        <div class="faq-three__img">
                            <div class="inner">
                                <img src="assets/images/resources/faq-v3-img1.jpg" alt="#">
                            </div>
                            <div class="overlay-content">
                                <div class="icon-box">
                                    <span class="icon-man"></span>
                                </div>

                                <div class="content-box">
                                    <p>From..</p>
                                    <h2>1994</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Faq Three Img-->
                </div>
            </div>
        </section>
        <!--End Faq Three -->