<!--Start Work Two -->
<section class="work-two">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Working Process</h6>
                    </div>
                    <h2 class="sec-title__title">Solve your issues in 4 <br>
                        easy steps</h2>
                </div>
                <div class="row">
                    <!--Start Work Two Content-->
                    <div class="col-xl-7">
                        <div class="work-two__content">
                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single wow fadeInLeft" data-wow-delay="100ms"
                                data-wow-duration="1000ms">
                                <div class="content-box">
                                    <h2>Make an Appointment</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>

                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>1 <span>st</span></h2>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->

                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single style2 wow fadeInLeft" data-wow-delay="300ms"
                                data-wow-duration="1000ms">
                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>2 <span>nd</span></h2>
                                </div>
                                <div class="content-box">
                                    <h2>Select your services</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->

                            <!--Start Work Two Content Single-->
                            <div class="work-two__content-single mb0 wow fadeInLeft" data-wow-delay="400ms"
                                data-wow-duration="1000ms">
                                <div class="content-box">
                                    <h2>Confirm for services</h2>
                                    <p>Nioremdolor amety consectetur notted tempor incididunt labore
                                        dolore magna mauris id auctor donect atestes ligula kacuse every
                                        resons credits to develop in level in the works process.</p>
                                </div>

                                <div class="number-box">
                                    <div class="border-box"></div>
                                    <h2>3 <span>rd</span></h2>
                                </div>
                            </div>
                            <!--End Work Two Content Single-->
                        </div>
                    </div>
                    <!--End Work Two Content-->

                    <!--Start Work Two Img-->
                    <div class="col-xl-5">
                        <div class="work-two__img clearfix">
                            <div class="inner clearfix">
                                <img src="assets/images/resources/work-v2-img1.png" alt="#">
                                <div class="work-two__video">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="work-two__video-btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Work Two Img-->
                </div>
            </div>
        </section>
        <!--End Work Two -->