<!--Start Video Two -->
<section class="video-two">
            <div class="video-two__bg" style="background-image: url(assets/images/backgrounds/video-v2-bg.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="video-two__inner">
                            <div class="video-two__content">
                                <h2>Need An Air Contioner <br>
                                    Technician</h2>
                                <p>Kula kacuse every reson credit to develop level works.</p>
                                <div class="border-box"></div>
                                <div class="contact-box">
                                    <div class="icon-box">
                                        <span class="icon-telephone"></span>
                                    </div>

                                    <div class="content-box">
                                        <p>Call anytime</p>
                                        <a href="tel:000-987458741">+000-987458741</a>
                                    </div>
                                </div>
                            </div>

                            <div class="video-two__video">
                                <div class="shape3 float-bob-x"><img src="assets/images/shapes/video-v2-shape3.png"
                                        alt=""></div>
                                <div class="video-two__video-icon">
                                    <div class="shape1"><img src="assets/images/shapes/video-v2-shape1.png" alt="#">
                                    </div>
                                    <div class="shape2"><img src="assets/images/shapes/video-v2-shape1.png" alt="#">
                                    </div>
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="video-two__video-btn video-popup">
                                        <span class="icon-play"></span>
                                    </a>
                                </div>

                                <div class="title-box">
                                    <h2>Watch How We Work</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Video Two -->