<!--Start Testimonial Two -->
<section class="testimonial-two">
            <div class="testimonial-two__bg"
                style="background-image: url(assets/images/backgrounds/testimonial-v2-bg.jpg);"></div>

            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Testimonials</h6>
                    </div>
                    <h2 class="sec-title__title">Our sweet customers</h2>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="testimonial-two__inner">

                            <div class="owl-carousel owl-theme thm-owl__carousel testimonial-two__carousel"
                                data-owl-options='{
                                    "loop": true,
                                    "autoplay": true,
                                    "margin": 30,
                                    "nav": true,
                                    "dots": false,
                                    "smartSpeed": 500,
                                    "autoplayTimeout": 10000,
                                    "navText": ["<span class=\"icon-right-arrow\"></span>","<span class=\"icon-left-arrow\"></span>"],
                                    "responsive": {
                                            "0": {
                                                "items": 1
                                            },
                                            "768": {
                                                "items": 3
                                            },
                                            "992": {
                                                "items": 3
                                            },
                                            "1200": {
                                                "items": 3
                                            }
                                        }
                                    }'>

                                <!--Start Testimonial Two Single-->
                                <div class="testimonial-two__single">
                                    <div class="quote-icon">
                                        <span class="icon-donation-4"></span>
                                    </div>
                                    <div class="img-box">
                                        <div class="inner">
                                            <img src="assets/images/testimonial/testimonial-v2-img1.jpg" alt="#">
                                        </div>
                                    </div>
                                    <div class="testimonial-two__single-inner text-center">
                                        <div class="author-box">
                                            <h2>Ramrian Mite</h2>
                                            <p>Manager</p>
                                        </div>

                                        <div class="text-box">
                                            <p>Nioremdolor amety consectetur notted tempor incid
                                                labore dolore magna mauris auctor donective
                                                atestes .</p>
                                        </div>

                                        <div class="rating-box">
                                            <ul>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!--End Testimonial Two Single-->

                                <!--Start Testimonial Two Single-->
                                <div class="testimonial-two__single">
                                    <div class="quote-icon">
                                        <span class="icon-donation-4"></span>
                                    </div>
                                    <div class="img-box">
                                        <div class="inner">
                                            <img src="assets/images/testimonial/testimonial-v2-img2.jpg" alt="#">
                                        </div>
                                    </div>
                                    <div class="testimonial-two__single-inner text-center">
                                        <div class="author-box">
                                            <h2>Jesing Towal</h2>
                                            <p>Director</p>
                                        </div>

                                        <div class="text-box">
                                            <p>Nioremdolor amety consectetur notted tempor incid
                                                labore dolore magna mauris auctor donective
                                                atestes .</p>
                                        </div>

                                        <div class="rating-box">
                                            <ul>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!--End Testimonial Two Single-->

                                <!--Start Testimonial Two Single-->
                                <div class="testimonial-two__single">
                                    <div class="quote-icon">
                                        <span class="icon-donation-4"></span>
                                    </div>
                                    <div class="img-box">
                                        <div class="inner">
                                            <img src="assets/images/testimonial/testimonial-v2-img3.jpg" alt="#">
                                        </div>
                                    </div>
                                    <div class="testimonial-two__single-inner text-center">
                                        <div class="author-box">
                                            <h2>Martine Singh</h2>
                                            <p>Founder</p>
                                        </div>

                                        <div class="text-box">
                                            <p>Nioremdolor amety consectetur notted tempor incid
                                                labore dolore magna mauris auctor donective
                                                atestes .</p>
                                        </div>

                                        <div class="rating-box">
                                            <ul>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                                <li>
                                                    <span class="icon-pointed-star"></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!--End Testimonial Two Single-->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Testimonial Two -->