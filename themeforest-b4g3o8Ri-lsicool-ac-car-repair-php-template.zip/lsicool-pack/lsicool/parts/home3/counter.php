<!--Start Counter Three -->
<section class="counter-three">
            <div class="auto-container">
                <div class="counter-three__inner">
                    <div class="counter-three__inner-box clearfix">
                        <div class="shape1"><img src="assets/images/shapes/contact-v3-shape1.png" alt="#"></div>
                        <div class="shape2"></div>
                        <div class="shape3"></div>
                        <ul class="clearfix">
                            <li>
                                <h2><span class="odometer" data-count="9">00</span> <span class="plus">+</span>
                                </h2>
                                <h3>Years of experience</h3>
                            </li>

                            <li>
                                <h2><span class="odometer" data-count="8">00</span> <span class="k">k</span> <span
                                        class="plus">+</span>
                                </h2>
                                <h3>Global customers</h3>
                            </li>

                            <li>
                                <h2><span class="odometer" data-count="17">00</span>
                                </h2>
                                <h3>Team enginners</h3>
                            </li>

                            <li>
                                <h2><span class="odometer" data-count="2">00</span> <span class="k">k</span> <span
                                        class="plus">+</span>
                                </h2>
                                <h3>Project completed</h3>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!--End Counter Three -->