<!--Start Services Three -->
<section class="services-three">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Our Services</h6>
                    </div>
                    <h2 class="sec-title__title">Make your Ac feel like a <br>
                        brand new one</h2>
                </div>
                <div class="row">
                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img1.jpg" alt="#">
                                    <div class="number-box">
                                        01
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-maintenance-1"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 01</p>
                                        <h2><a href="cooling-services.php">Industrial Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->

                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img2.jpg" alt="#">
                                    <div class="number-box">
                                        02
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-maintenance"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 02</p>
                                        <h2><a href="cooling-services.php">Heating Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->

                    <!--Start Services Three Single-->
                    <div class="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="200ms" data-wow-duration="1500ms">
                        <div class="services-three__single">
                            <div class="services-three__single-img">
                                <div class="inner">
                                    <img src="assets/images/services/services-v3-img3.jpg" alt="#">
                                    <div class="number-box">
                                        03
                                    </div>
                                </div>
                            </div>

                            <div class="services-three__single-content">
                                <div class="inner">
                                    <div class="icon-box">
                                        <span class="icon-air-conditioner-1"></span>
                                        <div class="left-border"></div>
                                        <div class="right-border"></div>
                                    </div>

                                    <div class="content-box">
                                        <p>Service 03</p>
                                        <h2><a href="cooling-services.php">Cleaning Service</a></h2>
                                        <div class="btn-box">
                                            <a href="cooling-services.php">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Three Single-->
                </div>
            </div>
        </section>
        <!--End Services Three -->