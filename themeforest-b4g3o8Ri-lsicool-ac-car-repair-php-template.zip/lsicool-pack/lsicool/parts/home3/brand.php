<!--Start Brand Three-->
<section class="brand-three">
            <div class="auto-container">
                <div class="brand-three__inner">
                    <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 5, "autoplay": { "delay": 5000 }, "breakpoints": {
                        "0": {
                            "spaceBetween": 30,
                            "slidesPerView": 1
                        },
                        "375": {
                            "spaceBetween": 30,
                            "slidesPerView": 1
                        },
                        "575": {
                            "spaceBetween": 30,
                            "slidesPerView": 2
                        },
                        "767": {
                            "spaceBetween": 30,
                            "slidesPerView": 3
                        },
                        "991": {
                            "spaceBetween": 30,
                            "slidesPerView": 3
                        },
                        "1199": {
                            "spaceBetween": 30,
                            "slidesPerView": 5
                        }
                    }}'>
                        <div class="swiper-wrapper">


                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img1.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img2.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img3.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img4.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img5.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img1.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img2.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img3.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img4.png" alt="#">
                            </div>

                            <div class="swiper-slide">
                                <img src="assets/images/brand/brand-v1-img5.png" alt="#">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Brand Three -->