<!--Start Team Three -->
<section class="team-three">
            <div class="container">
                <div class="sec-title style2 text-center">
                    <div class="sec-title__tagline">
                        <h6>Our Team</h6>
                    </div>
                    <h2 class="sec-title__title">Meet expert members</h2>
                </div>
                <div class="row">
                    <!--Start Team Three Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-three__single">
                            <div class="team-three__single-img">
                                <div class="team-three__single-img-inner">
                                    <img src="assets/images/team/team-v3-img1.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-instagram"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-three__single-content text-center">
                                <h2><a href="team-details.php">Alabert Smith</a></h2>
                                <p>Founder</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team Three Single-->

                    <!--Start Team Three Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-three__single">
                            <div class="team-three__single-img">
                                <div class="team-three__single-img-inner">
                                    <img src="assets/images/team/team-v3-img2.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-instagram"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-three__single-content text-center">
                                <h2><a href="team-details.php">Jason singh</a></h2>
                                <p>Director</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team Three Single-->

                    <!--Start Team Three Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-three__single">
                            <div class="team-three__single-img">
                                <div class="team-three__single-img-inner">
                                    <img src="assets/images/team/team-v3-img3.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-instagram"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-three__single-content text-center">
                                <h2><a href="team-details.php">Mahnia Thima </a></h2>
                                <p>Manager</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team Three Single-->

                    <!--Start Team Three Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-three__single">
                            <div class="team-three__single-img">
                                <div class="team-three__single-img-inner">
                                    <img src="assets/images/team/team-v3-img4.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-instagram"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-three__single-content text-center">
                                <h2><a href="team-details.php">Scott Lisech</a></h2>
                                <p>Technician</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team Three Single-->
                </div>
            </div>
        </section>
        <!--End Team Three -->