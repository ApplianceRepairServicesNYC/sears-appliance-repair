<!--Start About Three-->
<section class="about-three">
            <div class="about-three__bg" style="background-image: url(assets/images/about/about-v3-img1.jpg);"></div>
            <div class="container">
                <div class="row">
                    <!--Start About Three Img-->
                    <div class="col-xl-5">
                        <div class="about-three__img wow fadeInRight" data-wow-delay="100ms"
                            data-wow-duration="1500ms clearfix">
                            <div class="about-three__img-inner">
                                <img src="assets/images/about/about-v3-img2.jpg" alt="#">
                            </div>
                        </div>
                    </div>
                    <!--End About Three Img-->

                    <!--Start About Three Content-->
                    <div class="col-xl-7">
                        <div class="about-three__content">
                            <div class="sec-title style2">
                                <div class="sec-title__tagline">
                                    <h6>About Company</h6>
                                </div>
                                <h2 class="sec-title__title">Heating & Ac installation <br>
                                    repair company</h2>
                            </div>

                            <div class="about-three__content-text">
                                <p>Tempor indunt labore dolore magna mauris auctor donect at <br>
                                    ligulae kacuse for every resons credits.</p>
                            </div>

                            <div class="about-three__content-middle">
                                <div class="row">
                                    <div class="col-xl-5 col-lg-5 col-md-5">
                                        <div class="about-three__content-middle-left">
                                            <div class="top-content">
                                                <div class="icon-box">
                                                    <span class="icon-target"></span>
                                                </div>
                                                <div class="text-box">
                                                    <h2><span class="odometer" data-count="12">00</span> <span
                                                            class="plus">+</span> Years Of <br>
                                                        Experience
                                                    </h2>
                                                </div>
                                            </div>

                                            <ul class="about-three__content-middle-left-list">
                                                <li>
                                                    <div class="round-box"></div>
                                                    <div class="text-box">
                                                        <p>Courtesy Local Shuttle Service</p>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="round-box"></div>
                                                    <div class="text-box">
                                                        <p>24-Hour Roadside Assistance</p>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="round-box"></div>
                                                    <div class="text-box">
                                                        <p>Customer Rewards Program</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-xl-7 col-lg-7 col-md-7">
                                        <div class="about-three__content-middle-right">
                                            <ul class="about-three__content-middle-right-list clearfix">
                                                <li>
                                                    <div class="inner">
                                                        <div class="icon-box">
                                                            <span class="icon-air-conditioning"></span>
                                                        </div><!-- /.icon-box -->

                                                        <div class="content-box">
                                                            <h2>Qualified Specialists</h2>
                                                            <p>Kula kacuse every reson credit <br>
                                                                to develop level the works.</p>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="inner">
                                                        <div class="icon-box">
                                                            <span class="icon-air-conditioning"></span>
                                                        </div><!-- /.icon-box -->

                                                        <div class="content-box">
                                                            <h2>Qualified Specialists</h2>
                                                            <p>Kula kacuse every reson credit <br>
                                                                to develop level the works.</p>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="about-three__content-bottom">
                                <div class="btn-box">
                                    <a class="thm-btn" href="about.php">
                                        <span class="txt">Get More Info</span>
                                    </a>
                                </div>

                                <div class="signature-box">
                                    <h2>Rayika Monhania</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About Three Content-->
                </div>
            </div>
        </section>
        <!--End About Three-->