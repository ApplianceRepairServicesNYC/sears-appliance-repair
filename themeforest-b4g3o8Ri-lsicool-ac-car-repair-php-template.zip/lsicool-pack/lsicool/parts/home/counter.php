<!--Start Counter One -->
<section class="counter-one">
            <div class="container">
                <div class="counter-one__inner">
                    <ul class="clearfix">
                        <li>
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>Fun Facts</h6>
                                </div>
                                <h2 class="sec-title__title">Counter</h2>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-maintenance-1"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="17">00</span> <span class="k">k</span>
                                    </h2>
                                    <p>Completed Project</p>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-man"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="49">00</span> <span class="k">+</span>
                                    </h2>
                                    <p>Satisfied Clients</p>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class="inner">
                                <div class="icon-box">
                                    <span class="icon-target"></span>
                                </div>

                                <div class="text-box">
                                    <h2><span class="odometer" data-count="2">00</span> <span class="k">k</span>
                                    </h2>
                                    <p>Awards Winner</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Counter One -->