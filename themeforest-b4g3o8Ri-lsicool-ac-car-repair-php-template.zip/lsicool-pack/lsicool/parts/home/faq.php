<!--Start Faq One -->
<section class="faq-one">
            <div class="container">
                <div class="row">
                    <!--Start Faq One Left-->
                    <div class="col-xl-5">
                        <div class="faq-one__left clearfix">
                            <div class="faq-one__left-img clearfix">
                                <img src="assets/images/resources/faq-v1-img1.jpg" alt="#">
                            </div>

                            <div class="faq-one__left-inner">
                                <div class="faq-one__form wow fadeInLeft" data-wow-delay="100ms"
                                    data-wow-duration="1500ms">
                                    <div class="faq-one__form-bg"
                                        style="background-image: url(assets/images/backgrounds/faq-v1-form-bg.jpg);">
                                    </div>
                                    <div class="title-box">
                                        <h2>Free Consultation</h2>
                                    </div>

                                    <div class="form-box">
                                        <form method="post" action="https://unicktheme.com/lsicool/index.php">
                                            <div class="form-group">
                                                <input type="text" name="username" placeholder="FULL NAME" required="">
                                            </div>
                                            <div class="form-group">
                                                <input type="text" name="phone" placeholder="PHONE" required="">
                                            </div>
                                            <div class="form-group">
                                                <div class="select-box">
                                                    <select class="selectmenu wide">
                                                        <option selected="selected">CHOOSE SERVICES</option>
                                                        <option>CHOOSE SERVICES 01</option>
                                                        <option>CHOOSE SERVICES 02</option>
                                                        <option>CHOOSE SERVICES 03</option>
                                                        <option>CHOOSE SERVICES 04</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="WRITE MASSAGE"></textarea>
                                            </div>
                                            <div class="row">
                                                <div class="col-xl-12">
                                                    <div class="button-box">
                                                        <button class="thm-btn" type="submit"
                                                            data-loading-text="Please wait...">
                                                            <span class="txt">
                                                                Free Consultation
                                                            </span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Faq One Left-->

                    <!--Start Faq One Accordion-->
                    <div class="col-xl-7">
                        <div class="faq-one__accordion">
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>Asked Question</h6>
                                </div>
                                <h2 class="sec-title__title">Empower Lifes Forever Any <br>
                                    Better Living. </h2>
                            </div>
                            <ul class="accordion-box">
                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <div class="number-box">
                                            01
                                        </div>
                                        <div class="text">
                                            <h3>
                                                When can i expect to see my credit score ?
                                            </h3>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <p>Niorem lsum dolor amety consectetur notted tempors incididunt
                                            labore dolore utn magna alique mauris id auctor donec atestes ligula
                                            kacus for every resons of credits to develop in level.</p>
                                    </div>
                                </li>

                                <li class="accordion block active-block">
                                    <div class="acc-btn active">
                                        <div class="number-box">
                                            02
                                        </div>
                                        <div class="text">
                                            <h3>
                                                Con you remove from any credit report ?
                                            </h3>
                                        </div>
                                    </div>

                                    <div class="acc-content current">
                                        <p>Niorem lsum dolor amety consectetur notted tempors incididunt
                                            labore dolore utn magna alique mauris id auctor donec atestes ligula
                                            kacus for every resons of credits to develop in level.</p>
                                    </div>
                                </li>

                                <li class="accordion block bdrn">
                                    <div class="acc-btn">
                                        <div class="number-box">
                                            03
                                        </div>
                                        <div class="text">
                                            <h3>
                                                Why do i need reports from all 3 credit ?
                                            </h3>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <p>Niorem lsum dolor amety consectetur notted tempors incididunt
                                            labore dolore utn magna alique mauris id auctor donec atestes ligula
                                            kacus for every resons of credits to develop in level.</p>
                                    </div>
                                </li>
                            </ul>

                            <div class="faq-one__accordion-bottom">
                                <div class="icon-box">
                                    <span class="icon-maintenance-1"></span>
                                </div>

                                <div class="text-box">
                                    <h2>Don't Waste a Second! Call Us to Solve Your <br>
                                        Any Technical Problem</h2>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Faq One Accordion-->
                </div>
            </div>
        </section>
        <!--End Faq One -->