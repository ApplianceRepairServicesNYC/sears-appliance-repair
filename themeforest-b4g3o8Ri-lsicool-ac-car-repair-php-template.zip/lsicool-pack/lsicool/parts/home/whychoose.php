<!--Start Why Choose One -->
<section class="why-choose-one">
            <div class="why-choose-one__bg"
                style="background-image: url(assets/images/backgrounds/why-choose-v1-bg.jpg);"></div>
            <div class="container">
                <div class="why-choose-one__top">
                    <div class="sec-title">
                        <div class="sec-title__tagline">
                            <h6>Why Choose Us</h6>
                        </div>
                        <h2 class="sec-title__title">We Provide Full Range <br>
                            AC Services. </h2>
                    </div>

                    <div class="why-choose-one__top-text">
                        <p>Niorem lsum dolor amet consectetur notted temp incididunt
                            labore dolore utn magna alique mauris id auctor donec atestes
                            kacus for every resons of credits to develop in level.</p>
                    </div>
                </div>

                <div class="row">
                    <!--Start Why Choose One Img-->
                    <div class="col-xl-5">
                        <div class="why-choose-one__img">
                            <div class="inner">
                                <div class="shape1 float-bob-y"><img src="assets/images/shapes/why-choose-v1-shape1.png"
                                        alt="#">
                                </div>
                                <img src="assets/images/resources/why-choose-v1-img1.jpg" alt="#">
                                <div class="content-box">
                                    <div class="why-choose-one__icon">
                                        <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                            class="why-choose-one__btn video-popup">
                                            <span class="icon-play-1"></span>
                                        </a>
                                    </div>
                                    <h2>Watch Our <br>
                                        Video</h2>
                                </div>
                            </div>

                            <div class="why-choose-one__progress">
                                <div class="why-choose-one__progress-single">
                                    <div class="title-box">
                                        <h2>Industrial Electricians</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="87%">
                                            <div class="count-text">87%</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="why-choose-one__progress-single mb0">
                                    <div class="title-box">
                                        <h2>Residential Carpenters</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="60%">
                                            <div class="count-text">60%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--End Why Choose One Img-->

                    <!--Start Why Choose One Content-->
                    <div class="col-xl-7">
                        <div class="why-choose-one__content">
                            <div class="why-choose-one__content-bg"
                                style="background-image: url(assets/images/shapes/why-choose-bg.png);"></div>
                            <ul class="why-choose-one__content-list">
                                <li class="wow animated fadeInUp" data-wow-delay="0.1s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-maintenance-1"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>24/7 Customer Support</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="wow animated fadeInUp" data-wow-delay="0.2s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-air-conditioner-2"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>Affordable Service Prices</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="wow animated fadeInUp" data-wow-delay="0.3s">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="border"></div>
                                            <span class="icon-air-conditioner-1"></span>
                                        </div>

                                        <div class="text-box">
                                            <h2>Safe Solution For Home</h2>
                                            <p>Ideas auctor donec atest ligula kacus
                                                every resons of credits to develop in levels.</p>
                                            <div class="btn-box">
                                                <a href="#">Read Details</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Why Choose One Content-->
                </div>
            </div>
        </section>
        <!--End Why Choose One -->