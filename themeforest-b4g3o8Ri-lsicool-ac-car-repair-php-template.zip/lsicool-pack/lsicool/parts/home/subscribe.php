<!--Start Subscribe One -->
<section class="subscribe-one">
            <div class="auto-container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="subscribe-one__inner">
                            <div class="subscribe-one__bg"
                                style="background-image: url(assets/images/backgrounds/subscribe-v1-bg.jpg);"></div>

                            <div class="subscribe-one__inner-box">
                                <div class="subscribe-one__form">
                                    <form class="subscribe-form" action="#">
                                        <div class="input-box">
                                            <input type="email" name="email" placeholder="Email Address">
                                        </div>
                                        <button type="submit" class="thm-btn">
                                            <span class="txt">Subscribe Now</span>
                                        </button>
                                    </form>
                                </div>

                                <div class="subscribe-one__icon">
                                    <span class="icon-paper-plane-1"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Subscribe One -->