<!--Start Main Slider -->
<section class="main-slider main-slider-one">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5000
                }}'>
                <div class="swiper-wrapper">

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v1-img1.jpg)">
                        </div>
                        <div class="main-slider-one__img"><img src="assets/images/slides/slider-v1-img2.png" alt="#">
                        </div>

                        <div class="main-slider-one__outer-content">
                            <div class="social-links">
                                <ul>
                                    <li>
                                        <a href="#">Facebook</a>
                                    </li>

                                    <li>
                                        <a href="#">Instagram</a>
                                    </li>

                                    <li>
                                        <a href="#">Twitter</a>
                                    </li>

                                    <li>
                                        <a href="#">Pinterest</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="auto-container">
                            <div class="main-slider-one__content">
                                <div class="title">
                                    <h2>Heating & Air <br> Conditions Repair <br> Specialist</h2>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                        <div class="icon-box">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                    </a>
                                </div>

                                <div class="main-slider-one__video">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="slider-one__video-btn video-popup">
                                        <span class="icon-play-1"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v1-img2.jpg)">
                        </div>
                        <div class="main-slider-one__img"><img src="assets/images/slides/slider-v1-img2.png" alt="#">
                        </div>

                        <div class="main-slider-one__outer-content">
                            <div class="social-links">
                                <ul>
                                    <li>
                                        <a href="#">Facebook</a>
                                    </li>

                                    <li>
                                        <a href="#">Instagram</a>
                                    </li>

                                    <li>
                                        <a href="#">Twitter</a>
                                    </li>

                                    <li>
                                        <a href="#">Pinterest</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="auto-container">
                            <div class="main-slider-one__content">
                                <div class="title">
                                    <h2>Heating & Air <br> Conditions Repair <br> Specialist</h2>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                        <div class="icon-box">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                    </a>
                                </div>

                                <div class="main-slider-one__video">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="slider-one__video-btn video-popup">
                                        <span class="icon-play-1"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->

                    <!--Start Main Slider One-->
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image:url(assets/images/slides/slider-v1-img4.jpg)">
                        </div>
                        <div class="main-slider-one__img"><img src="assets/images/slides/slider-v1-img2.png" alt="#">
                        </div>

                        <div class="main-slider-one__outer-content">
                            <div class="social-links">
                                <ul>
                                    <li>
                                        <a href="#">Facebook</a>
                                    </li>

                                    <li>
                                        <a href="#">Instagram</a>
                                    </li>

                                    <li>
                                        <a href="#">Twitter</a>
                                    </li>

                                    <li>
                                        <a href="#">Pinterest</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="auto-container">
                            <div class="main-slider-one__content">
                                <div class="title">
                                    <h2>Heating & Air <br> Conditions Repair <br> Specialist</h2>
                                </div>

                                <div class="btn-box">
                                    <a class="thm-btn" href="contact.php">
                                        <span class="txt">Read More</span>
                                        <div class="icon-box">
                                            <i class="icon-right-arrow"></i>
                                        </div>
                                    </a>
                                </div>

                                <div class="main-slider-one__video">
                                    <a href="https://www.youtube.com/watch?v=pVE92TNDwUk"
                                        class="slider-one__video-btn video-popup">
                                        <span class="icon-play-1"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Main Slider One-->
                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-right-arrow"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-left-arrow"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--End Main Slider-->