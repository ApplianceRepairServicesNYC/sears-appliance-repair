<!--Start Testimonial One -->
<section class="testimonial-one">
            <div class="testimonial-one__img-two wow slideInRight" data-wow-delay="500ms" data-wow-duration="2500ms">
                <img src="assets/images/testimonial/testimonial-v1-img2.png" alt="#">
            </div>
            <div class="testimonial-one__pattern"
                style="background-image: url(assets/images/pattern/testimonial-v1-pattern.png);"></div>
            <div class="container">
                <div class="row">
                    <!--Start Testimonial One Left-->
                    <div class="col-xl-7">
                        <div class="testimonial-one__left">
                            <div class="testimonial-one__carousel-box">
                                <div class="owl-carousel owl-theme thm-owl__carousel testimonial-one__carousel dot-style1"
                                    data-owl-options='{
                                    "loop": true,
                                    "autoplay": true,
                                    "margin": 30,
                                    "nav": false,
                                    "dots": true,
                                    "smartSpeed": 500,
                                    "autoplayTimeout": 10000,
                                    "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-next\"></span>"],
                                    "responsive": {
                                            "0": {
                                                "items": 1
                                            },
                                            "768": {
                                                "items": 1
                                            },
                                            "992": {
                                                "items": 1
                                            },
                                            "1200": {
                                                "items": 1
                                            }
                                        }
                                    }'>

                                    <!--Start Testimonial One Single-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__single-img">
                                            <div class="inner">
                                                <img src="assets/images/testimonial/testimonial-v1-img1.jpg" alt="#">
                                                <div class="shape1"><img
                                                        src="assets/images/shapes/testimonial-v1-shape1.png" alt="#">
                                                </div>
                                            </div>
                                            <div class="border-box">
                                                <div class="icon"><img src="assets/images/icon/testimonial-v1-icon.png"
                                                        alt=""></div>
                                            </div>
                                        </div>

                                        <div class="testimonial-one__single-content text-center">
                                            <div class="author-info">
                                                <h2>Reason Singh</h2>
                                                <h3>Ceo Founder</h3>
                                            </div>

                                            <div class="text-box">
                                                <p>Niorem lsum dolo amety consectetur notted tempor adicte texttil
                                                    labore dolore utnise magna alique maurise id auctoir done testing
                                                    rettenr
                                                    kacus for every reson of credit to develop in level.</p>
                                            </div>

                                            <div class="icon-box">
                                                <span class="icon-left-quotes-sign"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End Testimonial One Single-->

                                    <!--Start Testimonial One Single-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__single-img">
                                            <div class="inner">
                                                <img src="assets/images/testimonial/testimonial-v1-img1.jpg" alt="#">
                                                <div class="shape1"><img
                                                        src="assets/images/shapes/testimonial-v1-shape1.png" alt="#">
                                                </div>
                                            </div>
                                            <div class="border-box">
                                                <div class="icon"><img src="assets/images/icon/testimonial-v1-icon.png"
                                                        alt=""></div>
                                            </div>
                                        </div>

                                        <div class="testimonial-one__single-content text-center">
                                            <div class="author-info">
                                                <h2>Reason Singh</h2>
                                                <h3>Ceo Founder</h3>
                                            </div>

                                            <div class="text-box">
                                                <p>Niorem lsum dolo amety consectetur notted tempor adicte texttil
                                                    labore dolore utnise magna alique maurise id auctoir done testing
                                                    rettenr
                                                    kacus for every reson of credit to develop in level.</p>
                                            </div>

                                            <div class="icon-box">
                                                <span class="icon-left-quotes-sign"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End Testimonial One Single-->

                                    <!--Start Testimonial One Single-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__single-img">
                                            <div class="inner">
                                                <img src="assets/images/testimonial/testimonial-v1-img1.jpg" alt="#">
                                                <div class="shape1"><img
                                                        src="assets/images/shapes/testimonial-v1-shape1.png" alt="#">
                                                </div>
                                            </div>
                                            <div class="border-box">
                                                <div class="icon"><img src="assets/images/icon/testimonial-v1-icon.png"
                                                        alt=""></div>
                                            </div>
                                        </div>

                                        <div class="testimonial-one__single-content text-center">
                                            <div class="author-info">
                                                <h2>Reason Singh</h2>
                                                <h3>Ceo Founder</h3>
                                            </div>

                                            <div class="text-box">
                                                <p>Niorem lsum dolo amety consectetur notted tempor adicte texttil
                                                    labore dolore utnise magna alique maurise id auctoir done testing
                                                    rettenr
                                                    kacus for every reson of credit to develop in level.</p>
                                            </div>

                                            <div class="icon-box">
                                                <span class="icon-left-quotes-sign"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End Testimonial One Single-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Testimonial One Left-->

                    <!--Start Testimonial Right -->
                    <div class="col-xl-5">
                        <div class="testimonial-one__right">
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>our testimonial</h6>
                                </div>
                                <h2 class="sec-title__title">What Our Clients <br>
                                    Saying About ? </h2>
                            </div>

                            <ul class="testimonial-one__right-list clearfix">
                                <li>
                                    <div class="inner">
                                        <div class="round-box"></div>
                                        <div class="text-box">
                                            <p>Affordable price upto 2 years</p>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="inner">
                                        <div class="round-box"></div>
                                        <div class="text-box">
                                            <p>Emergency solutions of mechanic services</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                            <div class="testimonial-one__right-text">
                                <p>Done testing rettenr kacus for every reson of <br>
                                    credit to develop in level.</p>
                            </div>
                        </div>
                    </div>
                    <!--End Testimonial Right -->
                </div>
            </div>
        </section>
        <!--End Testimonial One -->