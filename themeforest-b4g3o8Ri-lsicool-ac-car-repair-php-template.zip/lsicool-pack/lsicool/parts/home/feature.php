<!--Start Features One -->
<section class="features-one">
            <div class="auto-container">
                <div class="features-one__inner">
                    <div class="container">
                        <div class="row">
                            <!--Start Features One Single-->
                            <div class="col-xl-6 col-lg-6 wow fadeInLeft" data-wow-delay="100ms"
                                data-wow-duration="1000ms">
                                <div class="features-one__single">
                                    <div class="features-one__single-img">
                                        <div class="inner">
                                            <img src="assets/images/resources/features-v1-img1.jpg" alt="#">
                                            <div class="icon-box">
                                                <span class="icon-maintenance-2"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="features-one__single-content">
                                        <h3>Servicing</h3>
                                        <h2><a href="cooling-services.php">Quality Checkup</a></h2>
                                        <p>Dolore utn magna alique mauris id auctor <br>
                                            donec atestes ligula kacus resons.</p>
                                    </div>
                                </div>
                            </div>
                            <!--End Features One Single-->

                            <!--Start Features One Single-->
                            <div class="col-xl-6 col-lg-6 wow fadeInRight" data-wow-delay="200ms"
                                data-wow-duration="1000ms">
                                <div class="features-one__single style2">
                                    <div class="features-one__single-img">
                                        <div class="inner">
                                            <img src="assets/images/resources/features-v1-img1.jpg" alt="#">
                                            <div class="icon-box">
                                                <span class="icon-maintenance"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="features-one__single-content">
                                        <h3>Servicing</h3>
                                        <h2><a href="cooling-services.php">Dust Cleaning</a></h2>
                                        <p>Dolore utn magna alique mauris id auctor <br>
                                            donec atestes ligula kacus resons.</p>
                                    </div>
                                </div>
                            </div>
                            <!--End Features One Single-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Features One -->