<!--Start About One -->
<section class="about-one">
            <div class="container">
                <div class="row">
                    <!--Start About One Img-->
                    <div class="col-xl-6">
                        <div class="about-one__img wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1500ms">
                            <div class="about-one__img-inner">
                                <img src="assets/images/about/about-v1-img1.jpg" alt="#">
                                <div class="experience-box">
                                    <h2>Experience Of <br> <span class="odometer" data-count="12">00</span> <span
                                            class="plus">+</span> Years
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About One Img-->

                    <!--Start About One Content-->
                    <div class="col-xl-6">
                        <div class="about-one__content">
                            <div class="big-title">
                                <h2>About Us</h2>
                            </div>
                            <div class="sec-title">
                                <div class="sec-title__tagline">
                                    <h6>About Company</h6>
                                </div>
                                <h2 class="sec-title__title">Solutions For an Every <br> Repair Problems</h2>
                            </div>

                            <div class="about-one__content-text1">
                                <div class="text-box">
                                    <p>Niorem lsum dolor amety consectetur notted
                                        tempors incididunt labore dolore utn magna alique
                                        mauris id auctor donec atestes ligula lacus.</p>
                                </div>

                                <div class="icon-box">
                                    <span class="icon-air-conditioner"></span>
                                </div>
                            </div>

                            <div class="about-one__content-text2">
                                <div class="contant-box">
                                    <div class="contant-box-single">
                                        <div class="number-box">
                                            01
                                        </div>
                                        <div class="title-box">
                                            <h2>Safe Solutions <br> For Home</h2>
                                        </div>
                                    </div>

                                    <div class="contant-box-single mb0">
                                        <div class="number-box">
                                            02
                                        </div>
                                        <div class="title-box">
                                            <h2>Expert Team <br> Members</h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="img-box">
                                    <img src="assets/images/about/about-v1-img2.jpg" alt="#">
                                </div>
                            </div>

                            <div class="about-one__content-text3">
                                <div class="signature">
                                    <h3>Rabson Singhania</h3>
                                </div>
                                <div class="text-box">
                                    <h2>Ceo, Founder Of <br> Delta Group</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About One Content-->

                </div>
            </div>
        </section>
        <!--End About One -->