<!--Start Footer One -->
<footer class="footer-one">
            <div class="shape1"><img src="assets/images/shapes/footer-v1-shape1.png" alt="#"></div>
            <div class="footer-one__bg" style="background-image: url(assets/images/backgrounds/footer-one-bg.jpg);">
            </div>
            <!--Start Footer-->
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <!--Start Footer One Single-->
                        <div class="col-xl-3 col-lg-4 col-md-6  wow animated fadeInUp" data-wow-delay="0.1s">
                            <div class="footer-one__single footer-one__single-contact">
                                <div class="title">
                                    <h2>Contact</h2>
                                </div>

                                <div class="footer-one__single-contact-inner">
                                    <P>80 Road Broklyn Street, 600 <br> New York, USA</P>
                                    <h4> <span class="icon-email"></span> <a
                                            href="mailto:yourmail@email.com">needhelp@company.com</a></h4>

                                    <h4><span class="icon-telephone-call"></span> <a href="tel:926668880000">+92 666 888
                                            0000 </a></h4>
                                </div>
                            </div>
                        </div>
                        <!--End Footer One Single-->

                        <!--Start Footer One Single-->
                        <div class="col-xl-2 col-lg-4 col-md-6 wow animated fadeInUp" data-wow-delay="0.2s">
                            <div class="footer-one__single footer-one__single-link">
                                <div class="title">
                                    <h2>Link</h2>
                                </div>

                                <ul class="footer-one__single-list">
                                    <li><a href="about.php">About</a></li>
                                    <li><a href="team.php">Our Team</a></li>
                                    <li><a href="about.php">Upcoming Events</a></li>
                                    <li><a href="blog.php">Latest News</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>

                            </div>
                        </div>
                        <!--End Footer One Single-->

                        <!--Start Footer One Single-->
                        <div class="col-xl-2 col-lg-4 col-md-6 wow animated fadeInUp" data-wow-delay="0.3s">
                            <div class="footer-one__single footer-one__single-departments">
                                <div class="title">
                                    <h2>Departments</h2>
                                </div>

                                <ul class="footer-one__single-list">
                                    <li><a href="about.php">Health & Safety</a></li>
                                    <li><a href="about.php">Housing & Land</a></li>
                                    <li><a href="about.php">Legal & Finance</a></li>
                                    <li><a href="about.php">Transport & Traffic</a></li>
                                    <li><a href="about.php">Arts & Culture</a></li>
                                </ul>

                            </div>
                        </div>
                        <!--End Footer One Single-->

                        <!--Start Footer One Single-->
                        <div class="col-xl-2 col-lg-4 col-md-6 wow animated fadeInUp" data-wow-delay="0.4s">
                            <div class="footer-one__single footer-one__single-explore">
                                <div class="title">
                                    <h2>Explore</h2>
                                </div>

                                <ul class="footer-one__single-list">
                                    <li><a href="about.php">Privacy Policy
                                        </a></li>
                                    <li><a href="about.php">Our Services</a></li>
                                    <li><a href="about.php">Term & Condition</a></li>
                                    <li><a href="about.php">Pricing Plans</a></li>
                                </ul>

                            </div>
                        </div>
                        <!--End Footer One Single-->

                        <!--Start Footer One Single-->
                        <div class="col-xl-3 col-lg-4 col-md-6 wow animated fadeInUp" data-wow-delay="0.4s">
                            <div class="footer-one__single footer-one__single-gallery">
                                <div class="title">
                                    <h2>Gallery</h2>
                                </div>

                                <ul class="footer-one__single-gallery-box">
                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img1.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img1.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img2.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img2.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img3.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img3.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img4.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img4.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img5.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img5.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="img-box">
                                            <img src="assets/images/footer/footer-v1-img6.jpg" alt="#">
                                            <div class="icon-box">
                                                <a class="img-popup"
                                                    href="assets/images/footer/footer-v1-img6.jpg"><span
                                                        class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!--End Footer One Single-->
                    </div>
                </div>
            </div>
            <!--End Footer-->

            <div class="footer-one__bottom">
                <div class="auto-container">
                    <div class="bottom-inner">
                        <div class="footer-one__bottom-left">
                            <div class="logo-box"><a href="index.php"><img src="assets/images/resources/logo-2.png"
                                        alt=""></a></div>
                            <div class="social-links">
                                <ul>
                                    <li><a href="#"><span class="icon-facebook-app-symbol"></span></a></li>
                                    <li><a href="#"><span class="icon-twitter"></span></a></li>
                                    <li><a href="#"><span class="icon-pinterest"></span></a></li>
                                    <li><a href="#"><span class="icon-instagram"></span></a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="copyright">
                            <p>Copyright © 2025 <a href="index.php">Lsicool.</a> all rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--End Footer One-->