<?php $head_title="Home3 || lsicool || lsicool PHP Template"?>
<?php
$color_style_two=true;
?>
<?php require_once('parts/layout/top-layout.php'); ?>
<?php require_once('parts/header/header3.php'); ?>

<?php require_once('parts/home3/banner.php'); ?>
<?php require_once('parts/home3/feature.php'); ?>
<?php require_once('parts/home3/about.php'); ?>
<?php require_once('parts/home3/service.php'); ?>
<?php require_once('parts/home3/video.php'); ?>
<?php require_once('parts/home3/counter.php'); ?>
<?php require_once('parts/home3/faq.php'); ?>
<?php require_once('parts/home3/feature2.php'); ?>
<?php require_once('parts/home3/team.php'); ?>
<?php require_once('parts/home3/work.php'); ?>
<?php require_once('parts/home3/brand.php'); ?>
<?php require_once('parts/home3/testimonial.php'); ?>
<?php require_once('parts/home3/product.php'); ?>
<?php require_once('parts/home3/blog.php'); ?>

<?php require_once('parts/footer/footer2.php'); ?>
<?php require_once('parts/layout/bottom-layout.php'); ?>

       