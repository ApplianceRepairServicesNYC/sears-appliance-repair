<?php $head_title="Blog Details || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Blog Details";
require_once('parts/page-title.php');
?>


        <!--Start Blog Details -->
        <section class="blog-details">
            <div class="container">
                <div class="row">
                    <!--Start Sidebar-->
                    <div class="col-xl-4">
                        <div class="sidebar">
                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__search wow animated fadeInUp" data-wow-delay="0.1s">
                                <form action="#" class="sidebar__search-form">
                                    <input type="search" placeholder="Search...">
                                    <button type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__category wow animated fadeInUp" data-wow-delay="0.2s">
                                <h3 class="sidebar__title">Category</h3>
                                <ul class="sidebar__category-list">
                                    <li class="active"><a href="#">Cooling Services
                                            <span>(12)</span></a></li>
                                    <li><a href="installation.php">HVAS Installation
                                            <span>(15)</span></a></li>
                                    <li><a href="maintenance.php">AC Maintenance <span>(08)</span></a></li>
                                    <li><a href="heating.php">Heating and Water <span>(20)</span></a></li>
                                    <li><a href="dust-cleaning.php">Dust Cleaning <span>(14)</span></a></li>
                                    <li><a href="quality.php">Indoor Air Quality <span>(05)</span></a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__post">
                                <h3 class="sidebar__title">Recent Post</h3>
                                <div class="sidebar__post-box">
                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img1.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Eleifend aptent laoreet blandit <br>
                                                    consectetuer</a></h3>
                                        </div>
                                    </div>

                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img2.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Rhoncus ultrices ornare nets duis <br>
                                                    socis aliquet</a></h3>
                                        </div>
                                    </div>

                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img3.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Morbis dictums mentae felis this <br>
                                                    morbi magna</a></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__tags">
                                <h3 class="sidebar__title">Tags Cloud</h3>
                                <ul class="sidebar__tags-list clearfix">
                                    <li><a href="#">Heating</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">AC Care</a></li>
                                    <li><a href="#">Technology</a></li>
                                    <li><a href="#">Repair</a></li>
                                    <li><a href="#">Animals</a></li>
                                    <li><a href="#">Installation</a></li>
                                    <li><a href="#">Maintenance</a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->
                        </div>
                    </div>
                    <!--End Sidebar-->

                    <!--Start Blog Details Content-->
                    <div class="col-xl-8">
                        <div class="blog-details__content">
                            <!--Start Blog Page Single-->
                            <div class="blog-page__single">
                                <div class="blog-page__single-img">
                                    <div class="inner">
                                        <img src="assets/images/blog/blog-details-img1.jpg" alt="#">
                                    </div>
                                    <div class="date-box">
                                        20
                                        <br>
                                        June
                                    </div>
                                </div>

                                <div class="blog-page__single-content">
                                    <ul class="blog-page__meta">
                                        <li><a href="#"><i class="fa fa-user"></i><span>Paul Smith</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-comments"></i><span>0 Comment</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-heart"></i><span>0 Like</span></a>
                                        </li>
                                    </ul>
                                    <h2>Morbis dictums mentae felis this morbi magna</h2>
                                    <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                        officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste
                                        natus voluptatem accusantium doloremque laudantium, totam rem aperiam, </p>

                                    <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                        nisi commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                                        velit </p>
                                    <div class="btn-box">
                                        <a href="#">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Page Single-->

                            <div class="blog-details__content-img1">
                                <img src="assets/images/blog/blog-details-img2.jpg" alt="#">
                            </div>

                            <div class="blog-details__content-text1">
                                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiater nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                                    culpa quiei officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde
                                    omnis iste no error sit voluptatem accusantium doloremque laudantium, totam rem
                                    aperiam, </p>
                            </div>

                            <div class="blog-details__content-blockquote">
                                <div class="icon-box">
                                    <span class="icon-left-quotes-sign"></span>
                                </div>
                                <div class="text-box">
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusan atest
                                        doloremque laudantium, totam rem aperiam, eaque ipsa quae ilnventore veritatis
                                        et quasi architecto beatae vitae dicta sunt explicabo. </p>
                                </div>
                            </div>

                            <div class="blog-details__content-text2">
                                <p class="text1">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                                    dolore eu
                                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
                                    qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste
                                    natus error sit voluptatem accusantium doloremque laudantium </p>

                                <ul class="blog-details__content-text2-list">
                                    <li>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deser
                                    </li>
                                    <li> Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium con
                                    </li>
                                    <li>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,
                                    </li>
                                    <li>Excepteur sint occaecat cupidatat non proident, sunt culpa qui officia deserunt
                                        ert
                                    </li>
                                </ul>

                                <p class="text2">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus
                                    error sit tesect voluptatem accusantium doloremque laudantium, totam rem aperiam
                                    uyjre, </p>

                                <p class="text3">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                                    dolore eu fugiat is nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                                    sunt in culpa qui at officia deserunt mollit anim id est laborum. Sed ut
                                    perspiciatis unde omnis iste esi
                                    error sit voluptatem accusantium doloremque laudantium, totam a aperiam</p>
                            </div>

                            <div class="blog-details__bottom">
                                <p class="blog-details__tags">
                                    <a href="#">Office</a>
                                    <a href="#">Design</a>
                                    <a href="#">Clean</a>
                                </p>
                                <div class="blog-details__social-list">
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>

                            <div class="author-one">
                                <div class="inner">
                                    <div class="author-one__image">
                                        <img src="assets/images/blog/blog-details-img3.jpg" alt="#">
                                    </div>
                                    <div class="author-one__content">
                                        <h3>Mhon Smith</h3>
                                        <p>Them cattle had their you're female, living seed firmament earth saying mud
                                            you dark make heaven face carribian surface saying without.</p>
                                        <ul>
                                            <li><a href="#"><i class="fab fa-facebook-square"
                                                        aria-hidden="true"></i></a>
                                            </li>
                                            <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="comment-one">
                                <h3 class="comment-one__title">Comments (2)</h3>
                                <div class="comment-one__single">
                                    <div class="comment-one__image">
                                        <img src="assets/images/blog/blog-details-img4.jpg" alt="#">
                                    </div>
                                    <div class="comment-one__content">
                                        <h3>Strone Smith</h3>
                                        <p>Blessed heaven in seasons man were image void seasons given bearing greats
                                            fly multiply every deed you can surem dolor mesurement good.</p>
                                        <span>February 03. 2023 <a href="#" class="comment-one__btn">Reply</a></span>
                                    </div>
                                </div>

                                <div class="comment-one__single">
                                    <div class="comment-one__image">
                                        <img src="assets/images/blog/blog-details-img5.jpg" alt="#">
                                    </div>
                                    <div class="comment-one__content">
                                        <h3>Jhon Smith</h3>
                                        <p>Blessed heaven in seasons man were image void seasons given bearing greats
                                            fly all multiply every deed you can surem dolor mesurement good.</p>
                                        <span>February 03. 2023 <a href="#" class="comment-one__btn">Reply</a></span>
                                    </div>
                                </div>
                            </div>

                            <div class="comment-form">
                                <h3 class="comment-form__title">Leave A Reply</h3>
                                <form action="https://unicktheme.com/lsicool/assets/inc/sendemail.php" class="comment-one__form contact-form-validated"
                                    novalidate="novalidate">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="comment-form__input-box">
                                                <input type="text" placeholder="Your Name" name="name">
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="comment-form__input-box">
                                                <input type="email" placeholder="Email Address" name="email">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="comment-form__input-box comment-form__textarea">
                                                <textarea name="message" placeholder="Write Comment"></textarea>
                                            </div>

                                            <div class="comment-form__btn-box">
                                                <button class="thm-btn" type="submit"
                                                    data-loading-text="Please wait...">
                                                    <span class="txt">
                                                        Post Comment
                                                    </span>
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--End Blog Details Content-->

                </div>
            </div>
        </section>
        <!--End Blog Details -->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>
       