<?php $head_title="Quality || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Quality";
require_once('parts/page-title.php');
?>



        <!--Start Services Details-->
        <section class="services-details">
            <div class="container">
                <div class="row">
                    <!--Start Sidebar-->
                    <div class="col-xl-4">
                        <div class="sidebar">
                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__search wow animated fadeInUp" data-wow-delay="0.1s">
                                <form action="#" class="sidebar__search-form">
                                    <input type="search" placeholder="Search...">
                                    <button type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__category wow animated fadeInUp" data-wow-delay="0.2s">
                                <h3 class="sidebar__title">Category</h3>
                                <ul class="sidebar__category-list">
                                    <li><a href="cooling-services.php">Cooling Services <span>(12)</span></a></li>
                                    <li><a href="installation.php">HVAS Installation
                                            <span>(15)</span></a></li>
                                    <li><a href="maintenance.php">AC Maintenance <span>(08)</span></a></li>
                                    <li><a href="heating.php">Heating and Water <span>(20)</span></a></li>
                                    <li><a href="dust-cleaning.php">Dust Cleaning <span>(14)</span></a></li>
                                    <li class="active"><a href="#">Indoor Air Quality <span>(05)</span></a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__support wow animated fadeInUp" data-wow-delay="0.3s">
                                <div class="sidebar__support-bg"
                                    style="background-image: url(assets/images/services/services-details-img1.jpg);">
                                </div>
                                <h3 class="sidebar__suppot-title">Have Any Query?</h3>
                                <p class="sidebar__suppot-text">Great fruit grass their are first over spirit good whose
                                    very subdue</p>
                                <div class="sidebar__support-btn-box">
                                    <a class="thm-btn" href="#">
                                        <span class="txt">Send Message</span>
                                    </a>
                                </div>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__single-button-box wow animated fadeInUp"
                                data-wow-delay="0.4s">
                                <div class="btn-one">
                                    <a href="#">Download Doc <span class="fa fa-download"></span></a>
                                </div>

                                <div class="btn-one btn-one--two">
                                    <a href="#">Download Pdf<span class="fa fa-file-pdf"></span></a>
                                </div>
                            </div>
                            <!--End Sidebar Single-->
                        </div>
                    </div>
                    <!--End Sidebar-->


                    <!--Start Services Details Content-->
                    <div class="col-xl-8">
                        <div class="services-details__content">
                            <div class="services-details__content-img1">
                                <img src="assets/images/services/services-details-img9.jpg" alt="#">
                            </div>

                            <div class="text-box1">
                                <h2>Indoor Air Quality</h2>
                                <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt
                                    mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus error voluptatem
                                    accusantium doloremque laudantium, totam rem aperiam, eaque ipsa </p>

                                <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                                    commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit </p>

                                <ul>
                                    <li>
                                        <div class="icon">
                                            <span class="icon-tick"></span>
                                        </div>
                                        <div class="text">
                                            <p>Nostrud exercitation ullamco laboris consequat.reprehenderit in voluptate
                                                velit esse cillum
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="icon">
                                            <span class="icon-tick"></span>
                                        </div>
                                        <div class="text">
                                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                                                deserunt mollit
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <div class="text-box2">
                                <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut consequun magni
                                    dolores eos qui ratione volsnesciunt.Neque porro quisquam est, qui dolorem ipsum
                                    quia dolor sit amet, consectetur, sed quia non numquam eius modi tempora incidunt ut
                                    labore et dolore aliquam quaerat voluptatem. </p>

                                <ul>
                                    <li>
                                        <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                                            deserunt
                                        </p>
                                    </li>

                                    <li>
                                        <p> Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium

                                        </p>
                                    </li>

                                    <li>
                                        <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,

                                    </li>
                                </ul>
                            </div>

                            <div class="services-details__content-img2">
                                <img src="assets/images/services/services-details-img3.jpg" alt="#">
                            </div>

                            <div class="text-box3">
                                <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt
                                    mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus error voluptatem
                                    accusantium doloremque laudantium, totam rem aperiam, </p>

                                <p class="text2">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                                    dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                                    sunt in culpa quisit ,officia deserunt mollit anim id est laborum. Sed ut
                                    perspiciatis unde omnis is amet natus error sit voluptatem accusantium doloremque
                                    laudantium, totam reaperia eaque ipsa quae ab ilnventore veritatis et quasi
                                    architecto beatae vitae dicta sunt </p>
                            </div>

                            <div class="text-box4">
                                <div class="img-box">
                                    <img src="assets/images/services/services-details-img4.jpg" alt="#">
                                </div>

                                <div class="content-box">
                                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                        fugiat nulla pariatur. </p>

                                    <ul>
                                        <li>
                                            <div class="icon">
                                                <span class="icon-tick"></span>
                                            </div>

                                            <div class="text">
                                                <p>Duis aute irure dolor in reprehenderit in</p>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="icon">
                                                <span class="icon-tick"></span>
                                            </div>

                                            <div class="text">
                                                <p> voluptate velit esse cillum dolore eu fugiat </p>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="icon">
                                                <span class="icon-tick"></span>
                                            </div>

                                            <div class="text">
                                                <p>Kuis nostr exercitation ullamco laboris</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="text-box5">
                                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                                    mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus error voluptatem
                                    accusantium doloremque laudantium, totam rem aperiam, </p>
                            </div>

                        </div>
                    </div>
                    <!--End Services Details Content-->
                </div>
            </div>
        </section>
        <!--End Services Details-->

        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>