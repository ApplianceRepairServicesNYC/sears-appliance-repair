<?php $head_title="Team || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Team";
require_once('parts/page-title.php');
?>


        <!--Start Team One -->
        <section class="team-one team-one--team">
            <div class="shape3"><img src="assets/images/shapes/team-v1-shape2.png" alt="#"></div>
            <div class="container">
                <div class="sec-title text-center">
                    <div class="sec-title__tagline">
                        <h6>Our Experts</h6>
                    </div>
                    <h2 class="sec-title__title">Our Professional Team </h2>
                </div>
                <div class="row">
                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img1.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Albert Smith</a></h2>
                                <p>Founder</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img2.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Lukey Nobert</a></h2>
                                <p>Manager</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img3.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Steven Hang</a></h2>
                                <p>Engineer</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img4.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Markun Webb</a></h2>
                                <p>technician</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img5.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Rason Singh</a></h2>
                                <p>Engineer</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img6.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Hckims Rswana</a></h2>
                                <p>Founder</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img7.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Moniras Roy</a></h2>
                                <p>technician</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->

                    <!--Start Team One Single-->
                    <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="100ms"
                        data-wow-duration="1000ms">
                        <div class="team-one__single">
                            <div class="team-one__single-img">
                                <div class="inner">
                                    <div class="shape1"><img src="assets/images/shapes/team-v1-shape1.png" alt="#">
                                    </div>
                                    <img src="assets/images/team/team-v1-img8.jpg" alt="#">
                                    <ul class="social-links clearfix">
                                        <li class="share"><a href="#"><span class="icon-share"></span></a>
                                            <ul class="social-links-inner">
                                                <li><a href="#"><i class="icon-facebook-app-symbol"></i></a></li>
                                                <li><a href="#"><i class="icon-twitter"></i></a>
                                                </li>
                                                <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                                <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="team-one__single-content text-center">
                                <div class="shape2"></div>
                                <h2><a href="team-details.php">Steven Poul</a></h2>
                                <p>Manager</p>
                            </div>
                        </div>
                    </div>
                    <!--End Team One Single-->
                </div>
            </div>
        </section>
        <!--End Team One -->

        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>