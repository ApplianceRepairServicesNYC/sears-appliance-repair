<?php $head_title="Project Details || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Project Details";
require_once('parts/page-title.php');
?>


        <!--Start Project Details -->
        <section class="project-details">
            <div class="container">
                <div class="row">
                    <!--Start Project Details Content-->
                    <div class="col-xl-8">
                        <div class="project-details__content">
                            <div class="project-details__content-text1">
                                <h2>The Problems</h2>
                                <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt
                                    mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus error voluptatem
                                    accusantium doloremque laudantium, totam rem aperiam, eaque ipsa </p>
                                <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris at
                                    commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit </p>
                            </div>

                            <div class="project-details__content-text2">
                                <h2>The Solution</h2>
                                <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste natus
                                    error voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                                </p>

                                <ul class="project-details__content-text2-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-tick"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>Nostrud exercitation ullamco laboris consequat.reprehenderit in voluptate
                                                velit esse cillum </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-tick"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                                                deserunt mollit</p>
                                        </div>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <!--End Project Details Content-->

                    <!--Start Project Details Img-->
                    <div class="col-xl-4">
                        <div class="project-details__img">
                            <img src="assets/images/project/project-details-img1.jpg" alt="#">
                        </div>
                    </div>
                    <!--End Project Details Img-->
                </div>
            </div>
        </section>
        <!--End Project Details -->

        <!--Start Gallery Three -->
        <section class="gallery-three">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="gallery-three__inner">
                            <div class="owl-carousel owl-theme thm-owl__carousel gallery-three__carousel"
                                data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 20,
                                "nav": false,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"icon-right-arrow2\"></span>","<span class=\"icon-right-arrow21\"></span>"],
                                "responsive": {
                                        "0": {
                                            "items": 1
                                        },
                                        "768": {
                                            "items": 1
                                        },
                                        "992": {
                                            "items": 1
                                        },
                                        "1200": {
                                            "items": 1
                                        }
                                    }
                                }'>
                                <!--Start Gallery Three Single-->
                                <div class="gallery-three__single">
                                    <div class="gallery-three__single-img">
                                        <div class="gallery-three__single-img-inner">
                                            <img src="assets/images/gallery/gallery-v3-img1.jpg" alt="#">
                                        </div>

                                        <div class="overlay-content">
                                            <h2><a href="#">Quality Services</a></h2>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Three Single-->

                                <!--Start Gallery Three Single-->
                                <div class="gallery-three__single">
                                    <div class="gallery-three__single-img">
                                        <div class="gallery-three__single-img-inner">
                                            <img src="assets/images/gallery/gallery-v3-img2.jpg" alt="#">
                                        </div>

                                        <div class="overlay-content">
                                            <h2><a href="#">Quality Services</a></h2>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Three Single-->

                                <!--Start Gallery Three Single-->
                                <div class="gallery-three__single">
                                    <div class="gallery-three__single-img">
                                        <div class="gallery-three__single-img-inner">
                                            <img src="assets/images/gallery/gallery-v3-img3.jpg" alt="#">
                                        </div>

                                        <div class="overlay-content">
                                            <h2><a href="#">Quality Services</a></h2>
                                        </div>
                                    </div>
                                </div>
                                <!--End Gallery Three Single-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Gallery Three -->
        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>
       