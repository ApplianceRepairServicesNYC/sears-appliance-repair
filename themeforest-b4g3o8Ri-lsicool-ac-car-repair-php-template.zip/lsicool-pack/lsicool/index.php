<?php $head_title="Home || lsicool || lsicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<?php require_once('parts/header/header.php'); ?>

<?php require_once('parts/home/banner.php'); ?>
<?php require_once('parts/home/about.php'); ?>
<?php require_once('parts/home/counter.php'); ?>
<?php require_once('parts/home/service.php'); ?>
<?php require_once('parts/home/brand.php'); ?>
<?php require_once('parts/home/faq.php'); ?>
<?php require_once('parts/home/feature.php'); ?>
<?php require_once('parts/home/whychoose.php'); ?>
<?php require_once('parts/home/team.php'); ?>
<?php require_once('parts/home/testimonial.php'); ?>
<?php require_once('parts/home/blog.php'); ?>
<?php require_once('parts/home/subscribe.php'); ?>

<?php require_once('parts/footer/footer.php'); ?>
<?php require_once('parts/layout/bottom-layout.php'); ?>

        


       