<?php $head_title="Team Deatils || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Team Details";
require_once('parts/page-title.php');
?>


        <!--Start Team Details -->
        <section class="team-details">
            <div class="container">
                <div class="row">
                    <!--Start Team Details Img-->
                    <div class="col-xl-6">
                        <div class="team-details__img">
                            <img src="assets/images/team/team-details-img1.jpg" alt="#">
                        </div>
                    </div>
                    <!--End Team Details Img-->

                    <!--Start Team Details Content-->
                    <div class="col-xl-6">
                        <div class="team-details__content">
                            <div class="team-details__content-title">
                                <h2>Jhon Alberts</h2>
                                <p>Co mayor & developer</p>
                            </div>
                            <div class="team-details__content-social-links">
                                <ul>
                                    <li><a href="#"><span class="icon-twitter"></span></a></li>
                                    <li><a href="#"><span class="icon-facebook"></span></a></li>
                                    <li><a href="#"><span class="icon-pinterest"></span></a></li>
                                    <li><a href="#"><span class="icon-instagram"></span></a></li>
                                </ul>
                            </div>

                            <div class="team-details__content-bottom">
                                <h3>I help my government to stand out and my city people help me to grow.</h3>
                                <p>Lorem ipsum dolor sit amet, con adipiscing elit tiam convallis elit id impedie. Quisq
                                    commodo simply free ornare tortor. If you are going to use a passage of Lorem Ipsum,
                                    you need to be sure there isn't anything embarrassing hidden in the middle of text.
                                </p>
                                <ul class="team-details__content-bottom-list">
                                    <li>
                                        <p><span>Experience:</span> 26 Years</p>
                                    </li>

                                    <li>
                                        <p><span>Email:</span> <a href="mailto:yourmail@email.com">
                                                needhelp@gmail.com</a></p>
                                    </li>

                                    <li>
                                        <p><span>Phone:</span> <a href="tel:928800680">+ 92 (8800) -680</a></p>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <!--End Team Details Content-->
                </div>

                <div class="team-details__experience">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="team-details__experience-content">
                                <h2>Personal experience</h2>
                                <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't
                                    anything embarrassing hidden.</p>
                            </div>
                        </div>


                        <div class="col-xl-6">
                            <div class="team-details__progress">
                                <div class="team-details__progress-single">
                                    <div class="title-box">
                                        <h2>Consultation</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="90%">
                                            <div class="count-text">90%</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="team-details__progress-single">
                                    <div class="title-box">
                                        <h2>Growth</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="80%">
                                            <div class="count-text">80%</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="team-details__progress-single mb0">
                                    <div class="title-box">
                                        <h2>Dealing</h2>
                                    </div>

                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="70%">
                                            <div class="count-text">70%</div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Team Details -->

        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>