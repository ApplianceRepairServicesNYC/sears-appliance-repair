<?php $head_title="Home2 || lsicool || lsicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<?php require_once('parts/header/header2.php'); ?>

<?php require_once('parts/home2/banner.php'); ?>
<?php require_once('parts/home2/about.php'); ?>
<?php require_once('parts/home2/feature.php'); ?>
<?php require_once('parts/home2/service.php'); ?>
<?php require_once('parts/home2/feature2.php'); ?>
<?php require_once('parts/home2/brand.php'); ?>
<?php require_once('parts/home2/gallery.php'); ?>
<?php require_once('parts/home2/team.php'); ?>
<?php require_once('parts/home2/work.php'); ?>
<?php require_once('parts/home2/contact.php'); ?>
<?php require_once('parts/home2/faq.php'); ?>
<?php require_once('parts/home2/pricing.php'); ?>
<?php require_once('parts/home2/counter.php'); ?>
<?php require_once('parts/home2/video.php'); ?>
<?php require_once('parts/home2/blog.php'); ?>

<?php require_once('parts/footer/footer2.php'); ?>
<?php require_once('parts/layout/bottom-layout.php'); ?>

        