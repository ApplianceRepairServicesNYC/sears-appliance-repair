<?php $head_title="Blog || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Blog";
require_once('parts/page-title.php');
?>


        <!--Start Blog Page -->
        <section class="blog-page">
            <div class="container">
                <div class="row">
                    <!--Start Sidebar-->
                    <div class="col-xl-4">
                        <div class="sidebar">
                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__search wow animated fadeInUp" data-wow-delay="0.1s">
                                <form action="#" class="sidebar__search-form">
                                    <input type="search" placeholder="Search...">
                                    <button type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__category wow animated fadeInUp" data-wow-delay="0.2s">
                                <h3 class="sidebar__title">Category</h3>
                                <ul class="sidebar__category-list">
                                    <li class="active"><a href="#">Cooling Services
                                            <span>(12)</span></a></li>
                                    <li><a href="installation.php">HVAS Installation
                                            <span>(15)</span></a></li>
                                    <li><a href="maintenance.php">AC Maintenance <span>(08)</span></a></li>
                                    <li><a href="heating.php">Heating and Water <span>(20)</span></a></li>
                                    <li><a href="dust-cleaning.php">Dust Cleaning <span>(14)</span></a></li>
                                    <li><a href="quality.php">Indoor Air Quality <span>(05)</span></a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__post">
                                <h3 class="sidebar__title">Recent Post</h3>
                                <div class="sidebar__post-box">
                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img1.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Eleifend aptent laoreet blandit <br>
                                                    consectetuer</a></h3>
                                        </div>
                                    </div>

                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img2.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Rhoncus ultrices ornare nets duis <br>
                                                    socis aliquet</a></h3>
                                        </div>
                                    </div>

                                    <div class="sidebar__post-single">
                                        <div class="sidebar-post__img">
                                            <img src="assets/images/blog/recent-post-img3.jpg" alt="">
                                        </div>
                                        <div class="sidebar__post-content-box">
                                            <h3><a href="#">Morbis dictums mentae felis this <br>
                                                    morbi magna</a></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__tags">
                                <h3 class="sidebar__title">Tags Cloud</h3>
                                <ul class="sidebar__tags-list clearfix">
                                    <li><a href="#">Heating</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">AC Care</a></li>
                                    <li><a href="#">Technology</a></li>
                                    <li><a href="#">Repair</a></li>
                                    <li><a href="#">Animals</a></li>
                                    <li><a href="#">Installation</a></li>
                                    <li><a href="#">Maintenance</a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->
                        </div>
                    </div>
                    <!--End Sidebar-->

                    <!--Start Blog Page Content-->
                    <div class="col-xl-8">
                        <div class="blog-page__content">
                            <!--Start Blog Page Single-->
                            <div class="blog-page__single">
                                <div class="blog-page__single-img">
                                    <div class="inner">
                                        <img src="assets/images/blog/blog-page-img1.jpg" alt="#">
                                    </div>
                                    <div class="date-box">
                                        20
                                        <br>
                                        June
                                    </div>
                                </div>

                                <div class="blog-page__single-content">
                                    <ul class="blog-page__meta">
                                        <li><a href="#"><i class="fa fa-user"></i><span>Paul Smith</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-comments"></i><span>0 Comment</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-heart"></i><span>0 Like</span></a>
                                        </li>
                                    </ul>
                                    <h2><a href="blog-details.php">Eleifend apteent laoreet blandites consectetuer</a>
                                    </h2>
                                    <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                        officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste
                                        natus voluptatem accusantium doloremque laudantium, totam rem aperiam, </p>

                                    <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                        nisi commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                                        velit </p>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Page Single-->

                            <!--Start Blog Page Single-->
                            <div class="blog-page__single">
                                <div class="blog-page__single-img">
                                    <div class="inner">
                                        <img src="assets/images/blog/blog-page-img2.jpg" alt="#">
                                    </div>
                                    <div class="date-box">
                                        20
                                        <br>
                                        June
                                    </div>
                                </div>

                                <div class="blog-page__single-content">
                                    <ul class="blog-page__meta">
                                        <li><a href="#"><i class="fa fa-user"></i><span>Paul Smith</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-comments"></i><span>0 Comment</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-heart"></i><span>0 Like</span></a>
                                        </li>
                                    </ul>
                                    <h2><a href="blog-details.php">Morbis dictums mentae felis this morbi magna</a>
                                    </h2>
                                    <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                        officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste
                                        natus voluptatem accusantium doloremque laudantium, totam rem aperiam, </p>

                                    <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                        nisi commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                                        velit </p>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Page Single-->

                            <!--Start Blog Page Single-->
                            <div class="blog-page__single">
                                <div class="blog-page__single-img">
                                    <div class="inner">
                                        <img src="assets/images/blog/blog-page-img3.jpg" alt="#">
                                    </div>
                                    <div class="date-box">
                                        20
                                        <br>
                                        June
                                    </div>
                                </div>

                                <div class="blog-page__single-content">
                                    <ul class="blog-page__meta">
                                        <li><a href="#"><i class="fa fa-user"></i><span>Paul Smith</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-comments"></i><span>0 Comment</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-heart"></i><span>0 Like</span></a>
                                        </li>
                                    </ul>
                                    <h2><a href="blog-details.php">Rhoncus ultrices ornare nets duis socis aliquet
                                        </a></h2>
                                    <p class="text1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                        officia deserunt mollanim id est laborum. Sed ut perspiciatis unde omnis iste
                                        natus voluptatem accusantium doloremque laudantium, totam rem aperiam, </p>

                                    <p class="text2">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                        nisi commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                                        velit </p>
                                    <div class="btn-box">
                                        <a href="blog-details.php">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <!--End Blog Page Single-->

                            <ul class="styled-pagination clearfix">
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li class="next"><a href="#"><span class="icon-right-arrow"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Blog Page Content-->
                </div>
            </div>
        </section>
        <!--End Blog Page -->

        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>

       