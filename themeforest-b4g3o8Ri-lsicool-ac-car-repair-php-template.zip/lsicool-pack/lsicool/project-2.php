<?php $head_title="Project Two || lisicool || lisicool PHP Template"?>
<?php require_once('parts/layout/top-layout.php'); ?>
<!-- header -->
<?php require_once('parts/header/header.php'); ?>
<?php
$page_title = "Project Two";
require_once('parts/page-title.php');
?>

        <!--Start Project Page Two -->
        <section class="project-page-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <!--Start Project Page Two Menu Box-->
                        <div class="project-page-two__menu-box">
                            <ul class="project-filter clearfix post-filter has-dynamic-filters-counter">
                                <li data-filter=".filter-item" class="active"><span class="filter-text">All</span>
                                </li>
                                <li data-filter=".construction"><span class="filter-text">Construction</span></li>
                                <li data-filter=".engineering"><span class="filter-text">Engineering </span></li>
                                <li data-filter=".technology"><span class="filter-text">Technology</span></li>
                                <li data-filter=".material"><span class="filter-text">Material</span></li>
                            </ul>
                        </div>
                        <!--End Project Page Two Menu Box-->
                    </div>
                </div>

                <div class="row filter-layout masonary-layout">

                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item engineering construction">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img1.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img1.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">Repair & Cleaning</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->

                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item material technology">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img2.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img2.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">Emergency Repair</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->


                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item engineering construction">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img3.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img3.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">Checking Quality</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->


                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item technology material">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img4.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img4.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">AC Dust Cleaning</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->


                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item engineering construction">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img5.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img5.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">Repairman Checking</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->


                    <!--Start Project Page Two Single-->
                    <div class="col-xl-4 col-lg-4 col-md-6 filter-item material engineering">
                        <div class="project-page-two__single">
                            <div class="project-page-two__single-img">
                                <img src="assets/images/project/project-page-v2-img6.jpg" alt="#">
                                <div class="icon-box">
                                    <a class="img-popup2" href="assets/images/project/project-page-v2-img6.jpg"><span
                                            class="icon-zoom-in"></span></a>
                                </div>
                                <div class="btn-box">
                                    <a href="project-details.php">More Details <span
                                            class="icon-right-arrow"></span></a>
                                </div>
                            </div>

                            <div class="project-page-two__single-content text-center">
                                <h2><a href="project-details.php">Cooling Services</a></h2>
                            </div>
                        </div>
                    </div>
                    <!--End Project Page Two Single-->
                </div>
            </div>
        </section>
        <!--End Project Page Two -->


        <?php require_once('parts/footer/footer2.php'); ?>
        <?php require_once('parts/layout/bottom-layout.php'); ?>